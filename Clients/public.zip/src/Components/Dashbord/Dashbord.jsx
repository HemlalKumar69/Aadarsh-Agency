import React from "react";
import Navbarfrist from "./Navbarfrist";
import DashboardNav from "./DashboardNav";
import DashboardCards from "./DashboardCards";

const Dashbord = () => {
  return <div>{/* <DashboardCards/> */}</div>;
};

export default Dashbord;
