import React from 'react'

const Header = () => {
  return (
    <div>
          <h4 className='text-center mb-2'>SAMRIDDHI ENTERPRISES - JYOTHY</h4>
      <p className='text-center mb-1'>
        H.NO 2, NAGAR NIGAM COLONY COAL & TIMBER MARKET CHHOLA ROAD, BHOPAL
      </p>
      <p className='text-center mb-4'>Period : 01-04-2025 - 31-03-2026</p>
    </div>
  )
}

export default Header