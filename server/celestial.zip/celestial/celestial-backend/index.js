import express from "express";
import cors from "cors";
import Razorpay from "razorpay";
import "dotenv/config";
import cookieParser from "cookie-parser";
import mongoose from "mongoose";
import getApiController from "./src/routes/createTokenRoutes.js";
import authRoutes from "./src/routes/auth.routes.js";
import bookingRoutes from "./src/routes/booking.routes.js";
import { checkFlightToken } from "./src/middleware/checkFlightToken.js";
import { checkAuthToken } from "./src/middleware/checkAuthToken.js";
import Airport from "./src/model/airportSchema.js";
import path from "path";
import airportRoutes from "./src/routes/airport.routes.js";
import reviewRoutes from "./src/routes/review.routes.js";

const app = express();

app.post("/importschema", async (req, res) => {
  try {
    // 1️⃣ Get the absolute path of your Excel file
    const filePath = path.resolve("./src/ftd-travel-airport_list.xlsx");

    // 2️⃣ Read the Excel file
    const workbook = XLSX.readFile(filePath);
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const jsonData = XLSX.utils.sheet_to_json(sheet);

    if (!jsonData.length) {
      return res
        .status(400)
        .json({ success: false, message: "Excel file is empty." });
    }

    const airports = jsonData.map((row) => ({
      airportid: row["ï»¿airport_id"] || row["airport_id"] || "",
      airportcode: row["airport_code"] || "",
      airportname: row["airport_name"] || "",
      airportcity: row["airport_city"] || "",
      airportcountry: row["airport_country"] || "",
    }));

    // 4️⃣ Insert into MongoDB
    await Airport.insertMany(airports);

    // 5️⃣ Respond to Postman
    res.status(200).json({
      success: true,
      message: `${airports.length} records imported successfully.`,
    });
  } catch (error) {
    console.error("❌ Import error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to import data",
      error: error.message,
    });
  }
});

// === MIDDLEWARES ===
app.use(
  cors({
    origin: [
      "http://localhost:5173",
      "https://celestialtours.net",
      "https://www.celestialtours.net",
    ],
    credentials: true,
  })
);
app.use(express.json());
app.use(cookieParser());

const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    // console.log("✅ MongoDB connected successfully");
  } catch (error) {
    console.error("❌ MongoDB connection failed:", error.message);
    process.exit(1); // stop server if DB connection fails
  }
};

connectDB();

const razorpay = new Razorpay({
  key_id: process.env.KeyId, // 👈 Replace with your TEST Key ID
  key_secret: process.env.KeySecret, // 👈 Replace with your TEST Key Secret
});

// ✅ Create order API
app.post(
  "/create-order",
  checkAuthToken,
  checkFlightToken,
  async (req, res) => {
    try {
      const { amount } = req.body; // amount in INR

      // console.log(amount, "this is the amount");

      const options = {
        amount: amount * 100, // Razorpay works with paise
        currency: "INR",
        receipt: "order_rcptid_11",
      };

      const order = await razorpay.orders.create(options);
      // console.log(order, "this is the order");

      res.json({ success: true, order });
    } catch (error) {
      console.error("Razorpay Error:", error);
      res.status(500).json({ success: false, error });
    }
  }
);

// ✅ Define the route properly
app.get("/api/flight/checkToken", checkFlightToken, (req, res) => {
  res.json({
    success: true,
    message: "Token is valid!",
    token: req.flightToken,
  });
});

app.get("/api/checkAuth", checkAuthToken, (req, res) => {
  res.json({
    success: true,
    message: "Token is valid!",
    token: req.user,
  });
});
// === ROUTES ===
app.use("/api", getApiController);
app.use("/api/auth", authRoutes);
app.use("/api/airport", airportRoutes);
app.use("/api/review", reviewRoutes);

app.use("/api/booking", bookingRoutes);

// === MONGODB CONNECTION ===

// === START SERVER ===
const PORT = process.env.PORT || 3000;

app.listen(PORT, async () => {
  // await connectDB();
  // console.log(`🚀 Server running at http://localhost:${PORT}`);
});
