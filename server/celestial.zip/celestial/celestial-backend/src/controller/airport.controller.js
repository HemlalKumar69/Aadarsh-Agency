import Airport from "../model/airportSchema.js";
export const airportList = async (req, res) => {
  try {
    const airports = await Airport.find().sort({ airportname: 1 });
    res.status(200).json({
      message: "Airport list",
      success: true,
      data: airports,
    });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};
