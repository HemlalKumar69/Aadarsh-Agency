import FlightBooking from "../model/saveflight.model.js";
export const fetchBookingData = async (req, res) => {
  try {
    const bookingFlight = await FlightBooking.find({ userID: req.user?._id });

    if (!bookingFlight.length) {
      return res.status(401).json({
        message: "error while fetching booking data",
        success: false,
        data: [],
      });
    }
    res.status(200).json({
      message: "fetch all booking data By user Id",
      success: true,
      data: bookingFlight,
    });
  } catch (error) {
    res.status(500).json({
      message: "server error while fetching the booking data",
      success: false,
      data: [],
    });
  }
};
