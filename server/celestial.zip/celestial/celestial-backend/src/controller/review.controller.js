import Review from "../model/reviewSchema.js";

export const createReview = async (req, res) => {
  try {
    const { description, rating } = req.body;
    const userId = req.user._id;
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    const review = await Review.create({ userId, description, rating });
    res.status(200).json({
      message: "Review created successfully",
      success: true,
      data: review,
    });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

export const fetchAllReview = async (req, res) => {
  try {
    const userId = req.user._id;
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    const review = await Review.find({}).populate().select("-password");
    res.status(200).json({
      message: "Review created successfully",
      success: true,
      data: review,
    });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

export const fetchUserReview = async (req, res) => {
  try {
    const userId = req.user._id;
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    const review = await Review.find({ userId });
    res.status(200).json({
      message: "Review created successfully",
      success: true,
      data: review,
    });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};
