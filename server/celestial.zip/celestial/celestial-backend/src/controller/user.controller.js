import User from "../model/User.model.js";
import jwt from "jsonwebtoken";

const generateToken = (userId) => {
  return jwt.sign({ userId }, process.env.JWT_SECRET, { expiresIn: "1D" });
};

export const userLogin = async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({
        message: "all fields are required",
        success: false,
        data: [],
      });
    }

    const user = await User.findOne({ username });

    if (!user) {
      return res.status(400).json({
        message: "Wrong Credential",
      });
    }
    const checkpassword = await user.comparePassword(password);

    if (!checkpassword) {
      return res.status(400).json({ message: "Wrong Crdential" });
    }
    const token = generateToken(user._id);

    // ✅ Save token in cookie
    res.cookie("authToken", token, {
      httpOnly: true, // prevents JS access
      secure: process.env.NODE_ENV === "production", // true only on HTTPS
      sameSite: process.env.NODE_ENV === "production" ? "none" : "lax",
      maxAge: 2 * 24 * 60 * 60 * 1000, // 2 days
    });

    res.status(200).json({
      message: "User login successful",
      success: true,
      data: {
        id: user._id,
        username: user.username,
        email: user.email,
        role: user.role,
      },
    });
  } catch (error) {
    res.status(500).json({ message: "Server Error", error: error.message });
  }
};

export const userRegister = async (req, res) => {
  try {
    const { email, password, username } = req.body;
    if (!password || !email || !username) {
      return res.status(401).json({
        message: "all fields are required",
        success: false,
        data: [],
      });
    }
    if (password.length < 8) {
      return res.status(402).json({
        message: "password length should be greater than 8",
        success: false,
        data: [],
      });
    }
    const findUser = await User.findOne({ username });
    if (findUser) {
      return res.status(402).json({
        message: "User Name is already existed please choose unique one",
        success: false,
        data: [],
      });
    }

    const findEmail = await User.findOne({ email });
    if (findEmail) {
      return res.status(402).json({
        message: "email is already existed please choose unique one",
        success: false,
        data: [],
      });
    }

    const user = new User({
      username,
      email,
      password,
    });

    await user.save();
    res.status(200).json({
      message: "User registeration successfull",
      success: true,
      data: user,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

export const userLogout = async (req, res) => {
  try {
    // req.user.tokens = req.user.tokens.filter((token) => token.token !== req.token);
    // await req.user.save();
    res.clearCookie("authToken");
    res.status(200).json({ message: "User logout successfull", success: true });
  } catch (error) {
    res.status(500).json({ message: "Server Error", error: error.message });
  }
};
