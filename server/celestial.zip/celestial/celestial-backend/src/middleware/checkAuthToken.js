import jwt from "jsonwebtoken";
import User from "../model/User.model.js";

export const checkAuthToken = async (req, res, next) => {
  try {
    // 1️⃣ Get token from cookie
    const token = req.cookies.authToken;
    if (!token) {
      return res.status(401).json({
        success: false,
        message: "User is not authenticated. Please login first.",
      });
    }

    // 2️⃣ Verify token using your secret key
    const decoded = jwt.verify(token, process.env.JWT_SECRET); // ✅ correct syntax

    // decoded = { userId: "6718d96a9f..." , iat: 173..., exp: 173... }

    // 3️⃣ Check if that user still exists in DB
    const user = await User.findById(decoded.userId).select("-password"); // exclude password

    // console.log("asdfghjkl", user, "this is user");

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found. Please login again.",
      });
    }

    // 4️⃣ Attach user to request
    req.user = user;

    // 5️⃣ Continue
    next();
  } catch (error) {
    console.error("Token verification error:", error.message);

    return res.status(401).json({
      success: false,
      message: "Invalid or expired token. Please login again.",
    });
  }
};
