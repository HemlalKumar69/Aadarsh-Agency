// middleware/checkFlightToken.js
import jwt from "jsonwebtoken";

export const checkFlightToken = async (req, res, next) => {
  try {
    const token = req.cookies.flightToken;
    console.log(token,"ASDFGH");


    if (!token) {
      return res.status(401).json({
        success: false,
        message: "Token not found. Please generate a new one.",
      });
    }

    // (Optional) Verify or decode if your API tokens are JWT.
    // If not JWT, just skip this check.
    // jwt.verify(token, process.env.JWT_SECRET);

    req.flightToken = token; // attach it to the request for later use
    next();
  } catch (error) {
    console.error("Error verifying token:", error.message);
    res.status(401).json({
      success: false,
      message: "Invalid or expired token.",
    });
  }
};
