import mongoose from "mongoose";

const airportSchema = mongoose.Schema({
  airportid: {
    type: String,
  },
  airportcode: {
    type: String,
  },
  airportname: {
    type: String,
  },
  airportcity: {
    type: String,
  },
  airportcountry: {
    type: String,
  },
});

const Airport = mongoose.model("Airport", airportSchema);

export default Airport;
