import mongoose from "mongoose";

// --- Meal, Baggage, Seat (SSR) sub-schemas ---
const mealSchema = new mongoose.Schema({
  mealID: { type: String },
  mealAmt: { type: Number },
  mealDesc: { type: String },
  mealRef: { type: Number },
});

const baggSchema = new mongoose.Schema({
  baggID: { type: String },
  baggAmt: { type: Number },
  baggDesc: { type: String },
});

const seatSchema = new mongoose.Schema({
  seatID: { type: String },
  seatName: { type: String },
  seatAmt: { type: Number },
});

// --- SSR Info (Special Service Request) ---
const ssrInfoSchema = new mongoose.Schema({
  Onward: {
    Seat: [seatSchema],
    Bagg: baggSchema,
    Meal: [mealSchema],
  },
  Return: {
    Seat: [seatSchema],
    Bagg: baggSchema,
    Meal: [mealSchema],
  },
});

// --- Passenger schema ---
const passengerSchema = new mongoose.Schema({
  title: { type: String, required: true },
  fName: { type: String, required: true },
  lName: { type: String, required: true },
  pType: { type: String }, // Adult/Child/Infant (A/C/I)
  gender: { type: String },
  dob: { type: String },
  ppNo: { type: String },
  ppIss: { type: String },
  ppExp: { type: String },
  ppNat: { type: String },
  ssrInfo: ssrInfoSchema, // optional, only for SSR flights
});

// --- Booking schema ---
const flightBookingSchema = new mongoose.Schema(
  {
    passenger: { type: [passengerSchema], required: true },
    refID: { type: String, required: true },
    userID: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User", // <-- the name of your user model
      required: true,
    },
    clientID: { type: Number, required: true },
    flightID: { type: Number, required: true },
    mobile: { type: String, required: true },
    email: { type: String, required: true },
    bookingStatus: { type: String, default: "pending" }, // success, failed, etc.
    tripType: { type: String, required: true },
    serType: { type: String, required: true },
    response: { type: Object }, // store full API response
  },
  { timestamps: true }
);

export default mongoose.model("FlightBooking", flightBookingSchema);
