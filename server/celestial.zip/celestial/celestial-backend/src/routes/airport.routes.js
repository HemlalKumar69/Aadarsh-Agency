import express from "express";
import { airportList } from "../controller/airport.controller.js";

const route = express.Router();

route.get("/", airportList);

export default route;
