import express from "express";
import { userLogin, userRegister, userLogout } from "../controller/user.controller.js";
import { checkAuthToken } from "../middleware/checkAuthToken.js";
const route = express.Router();

route.post("/login", userLogin);
route.post("/register", userRegister);
route.get("/logout", checkAuthToken, userLogout);

export default route;
