import express from "express";
import { fetchBookingData } from "../controller/booking.controller.js";
import { checkAuthToken } from "../middleware/checkAuthToken.js";

const route = express.Router();

route.get("/", checkAuthToken, fetchBookingData);

export default route;
