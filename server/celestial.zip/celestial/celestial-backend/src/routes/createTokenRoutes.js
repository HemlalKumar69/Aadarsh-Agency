import express from "express";
import FlightBooking from "../model/saveflight.model.js";
import axios from "axios";
import { sendBookingEmail } from "../lib/sendMail.js";
import { checkFlightToken } from "../middleware/checkFlightToken.js";
import { checkAuthToken } from "../middleware/checkAuthToken.js";
const routes = express.Router();
// const API_URL = "https://www.ftd.travel/book/api";
const API_URL = "http://13.200.42.214/book/api";

const modeNumber = 0;

routes.get("/getToken", async (req, res) => {
  console.log(process.env.agentid);
  console.log(process.env.usernames);
  console.log(process.env.password);
  console.log(process.env.apikey);
  console.log(API_URL);

  try {
    const response = await axios.get(`${API_URL}/postCreateToken`, {
      headers: {
        agentid: process.env.agentid,
        username: process.env.usernames,
        password: process.env.password,
        mode: modeNumber,
        apikey: process.env.apikey,
      },
    });

    const token = response.data?.data; // 🔑 check the key name in API response

    console.log(token,"token");
    

    if (!token) {
      return res.status(400).json({
        message: "token did not created",
        success: false,
      });
    }
    // ✅ Store token in cookie for 1 day
    res.cookie("flightToken", token, {
      httpOnly: true, // secure from client-side JS
      secure: true, // set to true if using HTTPS
      sameSite: "none",
      maxAge: 24 * 60 * 60 * 1000, // 1 day
    });

    res.status(201).json({
      message: "Token created and stored successfully",
      success: true,
      data: response.data,
    });

    console.log(response.data);
    console.log(123098);
  } catch (error) {
    console.error("Error fetching token:", error.message);
    res.status(500).json({
      success: false,
      message: "Failed to fetch token",
      error: error.message,
    });
  }
});

routes.post("/postSearchFlight", checkFlightToken, async (req, res) => {
  try {
    const { ...searchData } = req.body;
    console.log("dfghjk");

    const flightToken = req.flightToken;

    const response = await axios.post(
      `${API_URL}/postSearchFlight`,
      searchData,
      {
        headers: {
          "x-api-key": flightToken,
          mode: modeNumber,
        },
      }
    );

    console.log(response?.data);

    res.status(200).json({
      success: true,
      message: "Flight Search Successfully",
      data: response.data,
    });
  } catch (error) {
    console.error("Error searching flight:", error.message);
    res.status(500).json({
      success: false,
      message: "Flight search failed",
      error: error.message,
    });
  }
});

routes.post("/postPriceVerify", checkFlightToken, async (req, res) => {
  try {
    const token = req.flightToken; // ✅ read from cookie

    if (!token) {
      return res.status(401).json({
        success: false,
        message: "Token not found. Please fetch a new token.",
      });
    }
    const response = await axios.post(`${API_URL}/postPriceVerify`, req.body, {
      headers: {
        "x-api-key": token,
        mode: modeNumber,
      },
    });

    res.status(200).json({
      message: "Check Flight Price Successfully",
      success: true,
      data: response.data,
    });
  } catch (error) {
    console.error("Error While searching flight Price:", error.message);
    res.status(500).json({
      success: false,
      message: "Check Flight Price failed",
      error: error.message,
    });
  }
});

routes.post(
  "/bookFlight",
  checkAuthToken,
  checkFlightToken,
  async (req, res) => {
    try {
      const {
        passenger,
        refID,
        selected,
        depCity,
        arrCity,
        onDate,
        mobile,
        flightID,
        email,
        serType,
        tripType,
      } = req.body;

      console.log(req.body.flightID, "this is the body");

      console.log(passenger, "this is the passenger data");

      const clientID = Math.floor(100000000000 + Math.random() * 900000000000);

      const payload = {
        passenger,
        refID,
        clientID,
        flightID,
        mobile,
        email,
      };

      console.log("Payload to API:", payload);

      const response = await axios.post(`${API_URL}/bookFlight`, payload, {
        headers: {
          apikey: process.env.apikey,
          mode: modeNumber,
          "Content-Type": "application/json",
        },
      });

      console.log(response?.data);

      // ✅ Save booking only when success
      if (response?.data?.success === 1) {
        const newBooking = new FlightBooking({
          passenger,
          refID,
          userID: req.user?._id,
          clientID,
          flightID,
          mobile,
          email,
          tripType,
          serType,
          bookingStatus: response.data.Status?.status || "success",
          response: response.data, // keep full API response
        });

        await newBooking.save();

        // ✅ Send confirmation email
        await sendBookingEmail({
          from: depCity,
          toCity: arrCity,
          clientMail: email,
          time: onDate,
          refID,
        });
      }

      res.status(200).json({
        message: "Flight Booked Successfully",
        success: true,
        data: response.data,
      });
    } catch (error) {
      console.error("Error while booking flight:", error.message);
      res.status(500).json({
        success: false,
        message: "Flight Booking Failed",
        error: error.message,
      });
    }
  }
);

routes.post("/seats", checkAuthToken, checkFlightToken, async (req, res) => {
  try {
    const token = req.flightToken;

    console.log(req.body, "req.body");
    console.log(token, "token");

    if (!token)
      return res.status(401).json({
        success: false,
        message: "Token not found. Please fetch a new token.",
      });

    // ✅ Delete the token from request body
    delete req.body.token;

    const response = await axios.post(`${API_URL}/seats`, req.body, {
      headers: { "x-api-key": token, mode: modeNumber },
    });

    res.status(200).json({
      message: "Seat map retrieved successfully",
      success: true,
      data: response.data,
    });
  } catch (error) {
    console.error("Error fetching seat map:", error.message);
    res.status(500).json({
      success: false,
      message: "Seat request failed",
      error: error.message,
    });
  }
});

routes.post(
  "/cancelFlight",
  checkAuthToken,
  checkFlightToken,
  async (req, res) => {
    try {
      const token = req.flightToken;
      if (!token)
        return res.status(401).json({
          success: false,
          message: "Token not found. Please fetch a new token.",
        });

      const response = await axios.post(`${API_URL}/cancelFlight`, req.body, {
        headers: { apikey: token, mode: modeNumber },
      });

      res.status(200).json({
        message: "Flight cancelled successfully",
        success: true,
        data: response.data,
      });
    } catch (error) {
      console.error("Error cancelling flight:", error.message);
      res.status(500).json({
        success: false,
        message: "Flight cancellation failed",
        error: error.message,
      });
    }
  }
);

routes.post(
  "/reschedule",
  checkAuthToken,
  checkFlightToken,
  async (req, res) => {
    try {
      const token = req.flightToken;
      if (!token)
        return res.status(401).json({
          success: false,
          message: "Token not found. Please fetch a new token.",
        });

      const response = await axios.post(`${API_URL}/reschedule`, req.body, {
        headers: { apikey: token, mode: modeNumber },
      });

      res.status(200).json({
        message: "Reissue quote retrieved successfully",
        success: true,
        data: response.data,
      });
    } catch (error) {
      console.error("Error fetching reissue quote:", error.message);
      res.status(500).json({
        success: false,
        message: "Reissue quote failed",
        error: error.message,
      });
    }
  }
);

routes.post(
  "/bookFlightSSR",
  checkAuthToken,
  checkFlightToken,
  async (req, res) => {
    try {
      const token = req.flightToken;

      if (!token) {
        return res.status(401).json({
          success: false,
          message: "Token not found. Please fetch a new token.",
        });
      }

      const response = await axios.post(`${API_URL}/bookFlight`, req.body, {
        headers: {
          apikey: process.env.apikey,
          mode: modeNumber,
        },
      });

      if (response?.data?.success === 1) {
        const bodyData = req.body;

        const newBooking = new FlightBooking({
          passenger: bodyData.passenger,
          refID: bodyData.refID,
          clientID: bodyData.clientID,
          flightID: bodyData.flightID,
          mobile: bodyData.mobile,
          email: bodyData.email,
          bookingStatus: response.data.Status?.status || "success",
          response: response.data,
        });

        await newBooking.save();
        // ✅ Send confirmation email
        const flightInfo = selected?.Flights?.Onward?.[0];
        await sendBookingEmail(email, {
          from: flightInfo?.Origin?.CityName,
          toCity: flightInfo?.Destination?.CityName,
          price: flightInfo?.Fare?.PublishedFare,
          time: flightInfo?.DepartureTime,
          baggage: flightInfo?.Baggage?.Adult,
          // seat: passengerArray[0]?.SeatNo,
          refID,
        });
      }

      res.status(200).json({
        message: "Flight Booked Successfully (with SSR)",
        success: true,
        data: response.data,
      });
    } catch (error) {
      console.error("Error booking flight with SSR:", error.message);
      res.status(500).json({
        success: false,
        message: "Booking with SSR failed",
        error: error.message,
      });
    }
  }
);

export default routes;
