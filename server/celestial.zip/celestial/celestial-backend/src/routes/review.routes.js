import express from "express";
import { createReview } from "../controller/review.controller.js";
import { checkAuthToken } from "../middleware/checkAuthToken.js";

const reviewRoutes = express.Router();
reviewRoutes.post("/create", checkAuthToken, createReview);
reviewRoutes.post("/Allfetch", checkAuthToken, createReview);
reviewRoutes.post("/Userfetch", checkAuthToken, createReview);
export default reviewRoutes;
