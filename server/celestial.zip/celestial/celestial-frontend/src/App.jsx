import React, { useState } from "react";
import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Homepage1 from "./components/Homepage1";
import Homepage2 from "./components/Homepage2";
import Homepage3 from "./components/Homepage3";
import Footer from "./components/Footer";
import Bookings from "./components/Bookings";
import { useSelector } from "react-redux";
import AuthForm from "./components/Auth.jsx";
import { ToastContainer } from "react-toastify";
import AdminRoute from "./components/AdminRoute.jsx";
import AdminDashboard from "./components/AdminDashboard.jsx";
function App() {
  const [activeTab, setActiveTab] = useState("flight");

  const authdata = useSelector((state) => state.auth.authdata);
  // console.log(authdata);

  const renderHomepage = () => {
    switch (activeTab) {
      case "hotel":
        return <Homepage1 />;
      case "flight":
        return <Homepage2 />;
      case "tour":
        return <Homepage3 />;
      default:
        return <Homepage2 />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <ToastContainer />
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />
      <Routes>
        <Route path="/" element={renderHomepage()} />
        <Route path="/bookings" element={<Bookings />} />
        <Route path="/login" element={<AuthForm />} />

        {/* Admin-only route */}
        <Route
          path="/admin/*"
          element={
            <AdminRoute>
              <AdminDashboard />
            </AdminRoute>
          }
        />
      </Routes>
      <Footer />
    </div>
  );
}

export default App;
