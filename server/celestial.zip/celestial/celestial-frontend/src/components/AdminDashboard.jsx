import React from "react";
import { Link, Routes, Route, Navigate } from "react-router-dom";
// import BookingPage from "./pages/BookingPage";
// import CancelPage from "./pages/CancelPage";
// import SchedulePage from "./pages/SchedulePage";

const AdminDashboard = () => {
  // console.log("asdfghjkl");

  const BookingPage = () => {
    return (
      <>
        <h1>booking</h1>
      </>
    );
  };

  const CancelPage = () => {
    return (
      <>
        <h1>cancel</h1>
      </>
    );
  };

  const SchedulePage = () => {
    return (
      <>
        <h1>schedule</h1>
      </>
    );
  };

  return (
    <div className="flex h-screen">
      <nav className="w-48 bg-gray-800 text-white p-6 flex flex-col gap-4">
        <h2 className="text-xl font-bold mb-6">Admin Dashboard</h2>
        <Link to="/admin/booking" className="hover:bg-gray-700 p-2 rounded">
          Booking
        </Link>
        <Link to="/admin/cancel" className="hover:bg-gray-700 p-2 rounded">
          Cancel
        </Link>
        <Link to="/admin/schedule" className="hover:bg-gray-700 p-2 rounded">
          Schedule
        </Link>
      </nav>

      <div className="flex-1 p-6 bg-gray-100 overflow-auto">
        <Routes>
          {/* Default landing page is Booking */}
          <Route index element={<Navigate to="booking" replace />} />
          <Route path="booking" element={<BookingPage />} />
          <Route path="cancel" element={<CancelPage />} />
          <Route path="schedule" element={<SchedulePage />} />
        </Routes>
      </div>
    </div>
  );
};

export default AdminDashboard;
