import React, { useEffect } from "react";
import { Navigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { checkUserLogin } from "../redux/reduxThunk/thunkAuthUser/AuthUser";

const AdminRoute = ({ children }) => {
  const dispatch = useDispatch();
  const authdata = useSelector((state) => state.auth.authdata);
  // console.log(authdata);

  useEffect(() => {
    dispatch(checkUserLogin());
  }, [dispatch]);

  // Still loading or empty
  if (!authdata || Object.keys(authdata).length === 0) {
    return null; // or a spinner if you like
  }

  // If user is not logged in or role is not admin, redirect to login
  if (!authdata || authdata.token?.role !== "admin") {
    return <Navigate to="/login" replace />;
  }

  return children;
};

export default AdminRoute;
