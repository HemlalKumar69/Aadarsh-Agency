import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { PlaneTakeoff } from "lucide-react"; // flight-themed icon
import { useDispatch } from "react-redux";
import {
  authUserLogin,
  authUserRegister,
} from "../redux/reduxThunk/thunkAuthUser/AuthUser";
// import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { useNavigate, useLocation } from "react-router-dom";

const AuthForm = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const dispatch = useDispatch();
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isLogin) {
      // console.log("Login with:", formData);
      dispatch(authUserLogin(formData))
        .unwrap()
        .then((res) => {
          // console.log("User registered successfully:", res);
          if (!res?.success) {
            toast("user did not login");
            return;
          }
          toast("user login successfull");
          const redirectPath = location.state?.from || "/";
          navigate(redirectPath, { replace: true });
          // navigate("/");
        })
        .catch((error) => {
          console.error("Registration failed:", error);
          toast("user login failed");
        });
      // Add login API call here
    } else {
      // console.log("Register with:", formData);
      dispatch(authUserRegister(formData))
        .unwrap()
        .then((response) => {
          // console.log("User registered successfully:", response);
          toast("user registeration successfull");
          setIsLogin(true);
        })
        .catch((error) => {
          console.error("Registration failed:", error);
          toast("user registeration failed");
        });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-sky-400 via-blue-500 to-indigo-600 p-4">
      <motion.div
        className="bg-white/90 backdrop-blur-lg rounded-2xl shadow-2xl p-8 w-full max-w-md"
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="flex justify-center mb-6">
          <motion.div
            initial={{ rotate: -10 }}
            animate={{ rotate: 0 }}
            transition={{ duration: 0.8 }}
          >
            <PlaneTakeoff size={50} className="text-sky-600" />
          </motion.div>
        </div>

        <h2 className="text-center text-3xl font-bold text-gray-800 mb-2">
          {isLogin ? "Welcome Back ✈️" : "Join the Sky Club ☁️"}
        </h2>
        <p className="text-center text-gray-500 mb-6">
          {isLogin
            ? "Login to continue booking your dream flight!"
            : "Create an account to start your journey."}
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <AnimatePresence mode="wait">
            {/* {!isLogin && ( */}
            <motion.div
              key="name"
              initial={{ opacity: 0, x: -40 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 40 }}
              transition={{ duration: 0.3 }}
            >
              <label className="block text-gray-700 font-medium mb-1">
                Full Name
              </label>
              <input
                type="text"
                name="username"
                value={formData.username}
                onChange={handleChange}
                placeholder="John Doe"
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-sky-400 outline-none"
              />
            </motion.div>
            {/* )} */}
          </AnimatePresence>
          {!isLogin && (
            <motion.div
              key="email"
              initial={{ opacity: 0, x: -40 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 40 }}
              transition={{ duration: 0.3 }}
            >
              <label className="block text-gray-700 font-medium mb-1">
                Email
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="you@example.com"
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-sky-400 outline-none"
              />
            </motion.div>
          )}

          <motion.div
            key="password"
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 40 }}
            transition={{ duration: 0.3 }}
          >
            <label className="block text-gray-700 font-medium mb-1">
              Password
            </label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="••••••••"
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-sky-400 outline-none"
            />
          </motion.div>

          <button
            type="submit"
            className="w-full py-3 bg-sky-600 text-white font-semibold rounded-lg hover:bg-sky-700 transition-colors duration-300"
          >
            {isLogin ? "Login" : "Register"}
          </button>
        </form>

        <div className="text-center mt-5">
          <p className="text-gray-600">
            {isLogin ? "Don’t have an account?" : "Already a member?"}{" "}
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="text-sky-600 font-semibold hover:underline"
            >
              {isLogin ? "Register" : "Login"}
            </button>
          </p>
        </div>
      </motion.div>
    </div>
  );
};

export default AuthForm;
