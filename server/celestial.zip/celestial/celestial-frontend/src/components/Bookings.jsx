import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  FaPlane,
  FaSync,
  FaSearch,
  FaTimes,
  FaCalendarAlt,
  FaClock,
  FaMapMarkerAlt,
  FaUsers,
  FaExclamationTriangle,
  FaCheckCircle,
} from "react-icons/fa";
import { useDispatch } from "react-redux";
import { fetchUserBookedTicked } from "../redux/reduxThunk/thunkBooking/Booking";
import { toast } from "react-toastify";

// const API_BASE = "http://localhost:3000";
const API_BASE = import.meta.env.VITE_URL || import.meta.env.VITE_URL2;

const Bookings = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [query, setQuery] = useState("");
  const [actionLoadingId, setActionLoadingId] = useState(null);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [showRescheduleModal, setShowRescheduleModal] = useState(false);
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [expandedBookings, setExpandedBookings] = useState({});
  const [rescheduleFormData, setRescheduleFormData] = useState({
    newDate: "",
    reason: "",
  });

  const dispatch = useDispatch();

  // Fetch bookings
  const fetchBookings = async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await dispatch(fetchUserBookedTicked()).unwrap();
      setBookings(result?.data || []);
    } catch (e) {
      setError("Failed to load bookings: " + e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBookings();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispatch]);

  // Open cancel confirmation modal
  const handleCancelClick = (booking) => {
    setSelectedBooking(booking);
    setShowCancelModal(true);
  };

  // Confirm cancellation
  const confirmCancelBooking = async () => {
    if (!selectedBooking) return;

    try {
      setActionLoadingId(
        selectedBooking._id || selectedBooking.refID || Math.random()
      );
      setError(null);

      const res = await fetch(`${API_BASE}/api/cancelFlight`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({
          reference: selectedBooking.refID || selectedBooking.reference,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success)
        throw new Error(data.message || "Cancel failed");

      toast.success("Flight cancelled successfully!", {
        position: "top-center",
        autoClose: 3000,
      });

      // Update local state
      setBookings((prev) =>
        prev.map((b) =>
          b._id === selectedBooking._id
            ? { ...b, bookingStatus: "CANCELLED" }
            : b
        )
      );

      setShowCancelModal(false);
      setSelectedBooking(null);
    } catch (e) {
      toast.error(e.message || "Cancellation failed", {
        position: "top-center",
        autoClose: 3000,
      });
      setError(e.message);
    } finally {
      setActionLoadingId(null);
    }
  };

  // Open reschedule confirmation modal
  const handleRescheduleClick = (booking) => {
    setSelectedBooking(booking);
    setRescheduleFormData({
      newDate: "",
      reason: "",
    });
    setShowRescheduleModal(true);
  };

  // Confirm reschedule
  const confirmRescheduleBooking = async () => {
    if (!selectedBooking) return;

    // Validate form data
    if (!rescheduleFormData.newDate) {
      toast.error("Please select a new date for rescheduling", {
        position: "top-center",
        autoClose: 3000,
      });
      return;
    }

    try {
      setActionLoadingId(
        selectedBooking._id || selectedBooking.refID || Math.random()
      );
      setError(null);

      // Get current flight details
      const onwardFlights =
        selectedBooking?.response?.flights?.Flights?.Onward || [];
      const firstFlight = onwardFlights[0] || {};
      const passengers = selectedBooking?.passenger || [];

      // Format the new date (YYYYMMDD format)
      const formatDateForAPI = (dateStr) => {
        const date = new Date(dateStr);
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const day = String(date.getDate()).padStart(2, "0");
        return `${year}${month}${day}`;
      };

      // Prepare reschedule payload
      const payload = {
        reference: selectedBooking.refID || selectedBooking.reference,
        refID: selectedBooking.refID,
        newDate: formatDateForAPI(rescheduleFormData.newDate),
        depCity:
          firstFlight.depCode ||
          selectedBooking?.response?.flights?.Flights?.Onward?.[0]?.depCode,
        arrCity:
          firstFlight.arrCode ||
          selectedBooking?.response?.flights?.Flights?.Onward?.slice(-1)[0]
            ?.arrCode,
        passenger: passengers.map((p) => ({
          title: p.title,
          fName: p.fName,
          lName: p.lName,
          pType: p.pType,
          gender: p.gender,
          dob: p.dob,
        })),
        reason: rescheduleFormData.reason || "Customer request",
        clientID: selectedBooking.clientID,
        flightID: selectedBooking.flightID,
        mobile: selectedBooking.mobile,
        email: selectedBooking.email,
      };

      const res = await fetch(`${API_BASE}/api/reschedule`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok || !data.success)
        throw new Error(data.message || "Reschedule failed");

      toast.success("Reschedule request submitted successfully!", {
        position: "top-center",
        autoClose: 3000,
      });

      // Update local state
      setBookings((prev) =>
        prev.map((b) =>
          b._id === selectedBooking._id
            ? { ...b, bookingStatus: "RESCHEDULE_REQUESTED" }
            : b
        )
      );

      setShowRescheduleModal(false);
      setSelectedBooking(null);
      setRescheduleFormData({ newDate: "", reason: "" });
    } catch (e) {
      toast.error(e.message || "Reschedule failed", {
        position: "top-center",
        autoClose: 3000,
      });
      setError(e.message);
    } finally {
      setActionLoadingId(null);
    }
  };

  // Toggle booking details expansion
  const toggleBookingDetails = (bookingId) => {
    setExpandedBookings((prev) => ({
      ...prev,
      [bookingId]: !prev[bookingId],
    }));
  };

  // Filter bookings
  const filtered = bookings?.filter((b) => {
    if (!query) return true;
    const hay = `${b.refID || ""} ${b?.response?.flights?.Flights?.Onward?.map(
      (f) => `${f.depCName} ${f.arrCName}`
    ).join(" ")}`.toLowerCase();
    return hay.includes(query.toLowerCase());
  });

  // Format date and time from YYYYMMDDHHMM format
  const formatDateTime = (dateTimeStr) => {
    if (!dateTimeStr || dateTimeStr.length !== 12)
      return { date: "N/A", time: "N/A" };

    try {
      const year = dateTimeStr.substring(0, 4);
      const month = dateTimeStr.substring(4, 6);
      const day = dateTimeStr.substring(6, 8);
      const hour = dateTimeStr.substring(8, 10);
      const minute = dateTimeStr.substring(10, 12);

      const date = new Date(`${year}-${month}-${day}`);
      const formattedDate = date.toLocaleDateString("en-US", {
        day: "numeric",
        month: "short",
        year: "numeric",
      });

      const formattedTime = `${hour}:${minute}`;

      return { date: formattedDate, time: formattedTime };
    } catch (error) {
      console.error("Error formatting date:", error);
      return { date: "N/A", time: "N/A" };
    }
  };

  // Get stop cities for a flight segment
  const getStopCities = (flights) => {
    if (!flights || flights.length <= 1) return [];

    const stopCities = [];
    for (let i = 0; i < flights.length - 1; i++) {
      const currentFlight = flights[i];
      const nextFlight = flights[i + 1];

      if (
        currentFlight.arrCode &&
        currentFlight.arrCName &&
        nextFlight.depCode &&
        nextFlight.depCName &&
        currentFlight.arrCode === nextFlight.depCode
      ) {
        stopCities.push({
          cityCode: currentFlight.arrCode,
          cityName: currentFlight.arrCName,
          layover: currentFlight.layover || "N/A",
        });
      }
    }
    return stopCities;
  };

  return (
    <section className="py-8 sm:py-12 bg-gray-50 min-h-screen">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">
            My Bookings
          </h1>
          <button
            onClick={fetchBookings}
            className="text-blue-600 hover:text-blue-700 flex items-center gap-2"
          >
            <FaSync /> Refresh
          </button>
        </div>

        {/* Search */}
        <div className="bg-white rounded-xl shadow p-4 mb-6 flex items-center gap-3">
          <FaSearch className="text-gray-400" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full outline-none"
            placeholder="Search by PNR, route, etc."
          />
        </div>

        {/* Error */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-red-700 mb-4">
            {error}
          </div>
        )}

        {/* Loading */}
        {loading ? (
          <div className="text-center py-8">Loading...</div>
        ) : filtered?.length === 0 ? (
          <div className="text-center py-8 text-gray-600">
            No bookings found.
          </div>
        ) : (
          <div className="space-y-6">
            {filtered?.map((b, idx) => {
              const bookingId = b._id || b.refID || idx;
              const isExpanded = expandedBookings[bookingId];

              // Try multiple possible paths for flight data
              const onwardFlights =
                b?.response?.flights?.Flights?.Onward ||
                b?.response?.Flights?.Onward ||
                b?.response?.flights?.Onward ||
                b?.response?.Onward ||
                [];

              const returnFlights =
                b?.response?.flights?.Flights?.Return ||
                b?.response?.Flights?.Return ||
                b?.response?.flights?.Return ||
                b?.response?.Return ||
                [];

              const fare =
                b?.response?.flights?.Fare?.total?.total ||
                b?.response?.Fare?.total?.total ||
                b?.response?.flights?.Fare?.PublishedFare ||
                b?.response?.Fare?.PublishedFare ||
                "0";

              const passengers = b?.passenger || [];
              const stops =
                b?.response?.flights?.Flights?.stops ||
                b?.response?.Flights?.stops ||
                b?.response?.flights?.stops ||
                "0";

              const pnr =
                b?.response?.ticket?.Onward?.passenger ||
                b?.response?.Ticket?.Onward?.passenger ||
                b?.response?.ticket?.passenger ||
                [];

              const bookingDate = b?.createdAt
                ? new Date(b.createdAt).toLocaleDateString()
                : "N/A";

              const totalAdults = passengers.filter(
                (p) => p.pType?.toLowerCase() === "a" || p.pType === "adt"
              ).length;
              const totalChildren = passengers.filter(
                (p) => p.pType?.toLowerCase() === "c" || p.pType === "chd"
              ).length;
              const totalInfants = passengers.filter(
                (p) => p.pType?.toLowerCase() === "i" || p.pType === "inf"
              ).length;

              const firstOnwardFlight = onwardFlights[0];
              const lastOnwardFlight =
                onwardFlights[onwardFlights.length - 1] || firstOnwardFlight;
              const firstReturnFlight = returnFlights[0];
              const lastReturnFlight =
                returnFlights[returnFlights.length - 1] || firstReturnFlight;

              // Get formatted date and time for departure and arrival
              const onwardDepartureDateTime = formatDateTime(
                firstOnwardFlight?.depDate
              );
              const onwardArrivalDateTime = formatDateTime(
                lastOnwardFlight?.arrDate
              );
              const returnDepartureDateTime = formatDateTime(
                firstReturnFlight?.depDate
              );
              const returnArrivalDateTime = formatDateTime(
                lastReturnFlight?.arrDate
              );

              // Get stop cities
              const onwardStopCities = getStopCities(onwardFlights);
              const returnStopCities = getStopCities(returnFlights);

              // Check if it's a round trip
              const isRoundTrip =
                b.tripType === "1" && returnFlights.length > 0;

              return (
                <motion.div
                  key={bookingId}
                  className="bg-white border border-gray-200 rounded-xl shadow-lg hover:shadow-xl transition-shadow overflow-hidden"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                >
                  {/* Main Booking Card */}
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-start gap-4 flex-1">
                        <div className="bg-blue-100 p-3 rounded-lg">
                          <FaPlane className="text-blue-600 text-xl" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-4">
                            <h3 className="text-xl font-bold text-gray-900">
                              {firstOnwardFlight?.depCName || "N/A"} →{" "}
                              {lastOnwardFlight?.arrCName || "N/A"}
                              {isRoundTrip && (
                                <span className="text-lg font-semibold text-blue-600 ml-2">
                                  ⇄ {lastOnwardFlight?.arrCName || "N/A"} →{" "}
                                  {firstOnwardFlight?.depCName || "N/A"}
                                </span>
                              )}
                            </h3>
                            <span
                              className={`px-3 py-1 rounded-full text-xs font-semibold ${
                                b.bookingStatus === "CANCELLED"
                                  ? "bg-red-100 text-red-700"
                                  : b.bookingStatus === "RESCHEDULE_REQUESTED"
                                  ? "bg-yellow-100 text-yellow-700"
                                  : "bg-green-100 text-green-700"
                              }`}
                            >
                              {b.bookingStatus?.toUpperCase() || "CONFIRMED"}
                              {isRoundTrip && " • ROUND TRIP"}
                            </span>
                          </div>

                          {/* Journey Details Grid */}
                          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            {/* Onward Journey */}
                            <div className="bg-blue-50 rounded-lg p-4">
                              <h4 className="font-semibold text-blue-800 mb-3 flex items-center gap-2">
                                <FaPlane className="text-blue-600" />
                                One Way Journey
                              </h4>
                              <div className="space-y-3 text-sm">
                                <div className="flex justify-between">
                                  <span className="text-gray-600">Route:</span>
                                  <span className="font-semibold">
                                    {firstOnwardFlight?.depCode} →{" "}
                                    {lastOnwardFlight?.arrCode}
                                  </span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">
                                    Departure:
                                  </span>
                                  <span className="font-semibold">
                                    {onwardDepartureDateTime.date} at{" "}
                                    {onwardDepartureDateTime.time}
                                  </span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-600">
                                    Arrival:
                                  </span>
                                  <span className="font-semibold">
                                    {onwardArrivalDateTime.date} at{" "}
                                    {onwardArrivalDateTime.time}
                                  </span>
                                </div>
                                {onwardStopCities.length > 0 && (
                                  <div className="flex justify-between">
                                    <span className="text-gray-600">
                                      Stops:
                                    </span>
                                    <span className="font-semibold text-right">
                                      {onwardStopCities.map((stop, index) => (
                                        <div key={index}>
                                          {stop.cityName} ({stop.cityCode})
                                        </div>
                                      ))}
                                    </span>
                                  </div>
                                )}
                              </div>
                            </div>

                            {/* Return Journey - Only for Round Trip */}
                            {isRoundTrip && (
                              <div className="bg-green-50 rounded-lg p-4">
                                <h4 className="font-semibold text-green-800 mb-3 flex items-center gap-2">
                                  <FaPlane className="text-green-600 transform rotate-180" />
                                  Return Journey
                                </h4>
                                <div className="space-y-3 text-sm">
                                  <div className="flex justify-between">
                                    <span className="text-gray-600">
                                      Route:
                                    </span>
                                    <span className="font-semibold">
                                      {firstReturnFlight?.depCode} →{" "}
                                      {lastReturnFlight?.arrCode}
                                    </span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-gray-600">
                                      Departure:
                                    </span>
                                    <span className="font-semibold">
                                      {returnDepartureDateTime.date} at{" "}
                                      {returnDepartureDateTime.time}
                                    </span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-gray-600">
                                      Arrival:
                                    </span>
                                    <span className="font-semibold">
                                      {returnArrivalDateTime.date} at{" "}
                                      {returnArrivalDateTime.time}
                                    </span>
                                  </div>
                                  {returnStopCities.length > 0 && (
                                    <div className="flex justify-between">
                                      <span className="text-gray-600">
                                        Stops:
                                      </span>
                                      <span className="font-semibold text-right">
                                        {returnStopCities.map((stop, index) => (
                                          <div key={index}>
                                            {stop.cityName} ({stop.cityCode})
                                          </div>
                                        ))}
                                      </span>
                                    </div>
                                  )}
                                </div>
                              </div>
                            )}
                          </div>

                          {/* Booking Information */}
                          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                            <div className="flex items-center gap-2">
                              <FaUsers className="text-blue-500" />
                              <span>
                                <strong>Passengers:</strong> {totalAdults} Adult
                                {totalAdults !== 1 ? "s" : ""}
                                {totalChildren > 0 &&
                                  `, ${totalChildren} Child${
                                    totalChildren !== 1 ? "ren" : ""
                                  }`}
                                {totalInfants > 0 &&
                                  `, ${totalInfants} Infant${
                                    totalInfants !== 1 ? "s" : ""
                                  }`}
                              </span>
                            </div>
                            {/* <div>
                              <span className="text-gray-500">
                                Booking Ref:
                              </span>{" "}
                              <span className="font-semibold">
                                {b.refID || "N/A"}
                              </span>
                            </div> */}
                            {pnr.length > 0 && (
                              <div>
                                <span className="text-gray-500">PNR:</span>{" "}
                                <span className="font-semibold">
                                  {pnr.map((p, i) => (
                                    <span key={i}>
                                      {p.pnr}
                                      {i < pnr.length - 1 && ", "}
                                    </span>
                                  ))}
                                </span>
                              </div>
                            )}
                            <div>
                              <span className="text-gray-500">Total Fare:</span>{" "}
                              <span className="font-bold text-blue-600">
                                ₹{fare}
                              </span>
                            </div>
                          </div>

                          {/* Additional Info */}
                          <div className="mt-3 flex flex-wrap gap-4 text-sm">
                            <div>
                              <span className="text-sm text-gray-600">
                                Flight ID: {b.flightID || "N/A"}
                              </span>
                            </div>
                            <div>
                              <span className="text-gray-500">Stops:</span>{" "}
                              <span className="font-semibold">{stops}</span>
                            </div>
                            <div>
                              <span className="text-gray-500">Trip Type:</span>{" "}
                              <span className="font-semibold">
                                {isRoundTrip ? "Round Trip" : "One Way"}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Expandable Details */}
                    <AnimatePresence>
                      {isExpanded && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.3 }}
                          className="overflow-hidden"
                        >
                          <div className="border-t pt-4 mt-4 space-y-4">
                            {/* Flight Details */}
                            <div>
                              <h4 className="font-semibold text-gray-900 mb-3">
                                Detailed Flight Information
                              </h4>

                              {/* Onward Flights */}
                              <div className="mb-6">
                                <h5 className="font-semibold text-gray-800 mb-3 text-lg flex items-center gap-2">
                                  <FaPlane className="text-blue-500" />
                                   Journey Details
                                </h5>
                                <div className="space-y-3">
                                  {onwardFlights.map((flight, fIdx) => {
                                    const flightDeparture = formatDateTime(
                                      flight.depDate
                                    );
                                    const flightArrival = formatDateTime(
                                      flight.arrDate
                                    );

                                    return (
                                      <div
                                        key={fIdx}
                                        className="bg-gray-50 p-4 rounded-lg border-l-4 border-blue-500"
                                      >
                                        <div className="flex items-center justify-between mb-2">
                                          <div>
                                            <span className="font-semibold">
                                              {flight.depCName} (
                                              {flight.depCode})
                                            </span>
                                            <span className="mx-2">→</span>
                                            <span className="font-semibold">
                                              {flight.arrCName} (
                                              {flight.arrCode})
                                            </span>
                                          </div>
                                          <span className="text-sm text-gray-600 bg-white px-2 py-1 rounded">
                                            Flight:{" "}
                                            {flight.flightNumber || "N/A"}
                                          </span>
                                        </div>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
                                          {/* Departure */}
                                          <div className="space-y-1">
                                            <div className="font-medium text-gray-900">
                                              Departure
                                            </div>
                                            <div className="pl-2">
                                              <div className="flex items-center gap-1">
                                                <FaCalendarAlt className="text-xs text-blue-500" />
                                                <span>
                                                  {flightDeparture.date}
                                                </span>
                                              </div>
                                              <div className="flex items-center gap-1">
                                                <FaClock className="text-xs text-blue-500" />
                                                <span>
                                                  {flightDeparture.time}
                                                </span>
                                              </div>
                                            </div>
                                          </div>

                                          {/* Arrival */}
                                          <div className="space-y-1">
                                            <div className="font-medium text-gray-900">
                                              Arrival
                                            </div>
                                            <div className="pl-2">
                                              <div className="flex items-center gap-1">
                                                <FaCalendarAlt className="text-xs text-blue-500" />
                                                <span>
                                                  {flightArrival.date}
                                                </span>
                                              </div>
                                              <div className="flex items-center gap-1">
                                                <FaClock className="text-xs text-blue-500" />
                                                <span>
                                                  {flightArrival.time}
                                                </span>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                        <div className="mt-2 text-sm text-gray-600">
                                          <span className="font-medium">
                                            Duration:
                                          </span>{" "}
                                          {flight.duration ||
                                            flight.flightDuration ||
                                            flight.Duration ||
                                            "N/A"}{" "}
                                          mins
                                          {flight.layover && (
                                            <span className="ml-4">
                                              <span className="font-medium">
                                                Layover:
                                              </span>{" "}
                                              {flight.layover}
                                            </span>
                                          )}
                                        </div>
                                        <div className="mt-1 text-sm text-gray-600">
                                          <span className="font-medium">
                                            Airline:
                                          </span>{" "}
                                          {flight.airName || "N/A"} (
                                          {flight.airCode || "N/A"})
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>
                              </div>

                              {/* Return Flights - Only for Round Trip */}
                              {isRoundTrip && (
                                <div>
                                  <h5 className="font-semibold text-gray-800 mb-3 text-lg flex items-center gap-2">
                                    <FaPlane className="text-green-500 transform rotate-180" />
                                    Return Journey Details
                                  </h5>
                                  <div className="space-y-3">
                                    {returnFlights.map((flight, fIdx) => {
                                      const flightDeparture = formatDateTime(
                                        flight.depDate
                                      );
                                      const flightArrival = formatDateTime(
                                        flight.arrDate
                                      );

                                      return (
                                        <div
                                          key={fIdx}
                                          className="bg-gray-50 p-4 rounded-lg border-l-4 border-green-500"
                                        >
                                          <div className="flex items-center justify-between mb-2">
                                            <div>
                                              <span className="font-semibold">
                                                {flight.depCName} (
                                                {flight.depCode})
                                              </span>
                                              <span className="mx-2">→</span>
                                              <span className="font-semibold">
                                                {flight.arrCName} (
                                                {flight.arrCode})
                                              </span>
                                            </div>
                                            <span className="text-sm text-gray-600 bg-white px-2 py-1 rounded">
                                              Flight:{" "}
                                              {flight.flightNumber || "N/A"}
                                            </span>
                                          </div>
                                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
                                            {/* Departure */}
                                            <div className="space-y-1">
                                              <div className="font-medium text-gray-900">
                                                Departure
                                              </div>
                                              <div className="pl-2">
                                                <div className="flex items-center gap-1">
                                                  <FaCalendarAlt className="text-xs text-green-500" />
                                                  <span>
                                                    {flightDeparture.date}
                                                  </span>
                                                </div>
                                                <div className="flex items-center gap-1">
                                                  <FaClock className="text-xs text-green-500" />
                                                  <span>
                                                    {flightDeparture.time}
                                                  </span>
                                                </div>
                                              </div>
                                            </div>

                                            {/* Arrival */}
                                            <div className="space-y-1">
                                              <div className="font-medium text-gray-900">
                                                Arrival
                                              </div>
                                              <div className="pl-2">
                                                <div className="flex items-center gap-1">
                                                  <FaCalendarAlt className="text-xs text-green-500" />
                                                  <span>
                                                    {flightArrival.date}
                                                  </span>
                                                </div>
                                                <div className="flex items-center gap-1">
                                                  <FaClock className="text-xs text-green-500" />
                                                  <span>
                                                    {flightArrival.time}
                                                  </span>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                          <div className="mt-2 text-sm text-gray-600">
                                            <span className="font-medium">
                                              Duration:
                                            </span>{" "}
                                            {flight.duration ||
                                              flight.flightDuration ||
                                              flight.Duration ||
                                              "N/A"}{" "}
                                            mins
                                            {flight.layover && (
                                              <span className="ml-4">
                                                <span className="font-medium">
                                                  Layover:
                                                </span>{" "}
                                                {flight.layover}
                                              </span>
                                            )}
                                          </div>
                                          <div className="mt-1 text-sm text-gray-600">
                                            <span className="font-medium">
                                              Airline:
                                            </span>{" "}
                                            {flight.airName || "N/A"} (
                                            {flight.airCode || "N/A"})
                                          </div>
                                        </div>
                                      );
                                    })}
                                  </div>
                                </div>
                              )}
                            </div>

                            {/* Passenger Details */}
                            <div>
                              <h4 className="font-semibold text-gray-900 mb-3">
                                Passenger Details
                              </h4>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                {passengers.map((passenger, pIdx) => (
                                  <div
                                    key={pIdx}
                                    className="bg-gray-50 p-3 rounded-lg"
                                  >
                                    <div className="font-medium">
                                      {passenger.title} {passenger.fName}{" "}
                                      {passenger.lName}
                                    </div>
                                    <div className="text-sm text-gray-600">
                                      Type:{" "}
                                      {passenger.pType?.toUpperCase() || "N/A"}{" "}
                                      • Age:{" "}
                                      {passenger.dob
                                        ? new Date().getFullYear() -
                                          new Date(passenger.dob).getFullYear()
                                        : "N/A"}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>

                            {/* Contact Information */}
                            <div>
                              <h4 className="font-semibold text-gray-900 mb-3">
                                Contact Information
                              </h4>
                              <div className="bg-gray-50 p-3 rounded-lg">
                                <div className="text-sm">
                                  <div>
                                    <span className="font-medium">Email:</span>{" "}
                                    {b.email || "N/A"}
                                  </div>
                                  <div className="mt-1">
                                    <span className="font-medium">Mobile:</span>{" "}
                                    {b.mobile || "N/A"}
                                  </div>
                                  <div className="mt-1">
                                    <span className="font-medium">
                                      Booking Date:
                                    </span>{" "}
                                    {bookingDate}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-between mt-6 pt-4 border-t">
                      <button
                        onClick={() => toggleBookingDetails(bookingId)}
                        className="text-blue-600 hover:text-blue-700 font-medium flex items-center gap-2"
                      >
                        {isExpanded ? "Hide Details" : "View Details"}
                        <FaPlane
                          className={`transform transition-transform ${
                            isExpanded ? "rotate-180" : ""
                          }`}
                        />
                      </button>
                      <div className="flex gap-3">
                        <button
                          disabled={
                            actionLoadingId !== null ||
                            b.bookingStatus === "CANCELLED"
                          }
                          onClick={() => handleRescheduleClick(b)}
                          className="px-6 py-2 rounded-lg bg-yellow-500 text-white hover:bg-yellow-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium flex items-center gap-2"
                        >
                          <FaSync />
                          Reschedule
                        </button>
                        <button
                          disabled={
                            actionLoadingId !== null ||
                            b.bookingStatus === "CANCELLED"
                          }
                          onClick={() => handleCancelClick(b)}
                          className="px-6 py-2 rounded-lg bg-red-600 text-white hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium flex items-center gap-2"
                        >
                          <FaTimes />
                          Cancel
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* Cancel Confirmation Modal */}
      <AnimatePresence>
        {showCancelModal && selectedBooking && (
          <motion.div
            className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => {
              setShowCancelModal(false);
              setSelectedBooking(null);
            }}
          >
            <motion.div
              className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto"
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="bg-red-100 p-3 rounded-full">
                      <FaExclamationTriangle className="text-red-600 text-xl" />
                    </div>
                    <h2 className="text-2xl font-bold text-gray-900">
                      Confirm Cancellation
                    </h2>
                  </div>
                  <button
                    onClick={() => {
                      setShowCancelModal(false);
                      setSelectedBooking(null);
                    }}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <FaTimes className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <p className="text-sm text-yellow-800">
                      <strong>Warning:</strong> Cancelling your flight booking
                      will result in cancellation charges as per airline policy.
                    </p>
                  </div>

                  <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                    <h3 className="font-semibold text-gray-900">
                      Booking Details
                    </h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">
                          Booking Reference:
                        </span>
                        <span className="font-semibold">
                          {selectedBooking.refID || "N/A"}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Route:</span>
                        <span className="font-semibold">
                          {selectedBooking?.response?.flights?.Flights
                            ?.Onward?.[0]?.depCName || "N/A"}{" "}
                          →{" "}
                          {selectedBooking?.response?.flights?.Flights?.Onward?.slice(
                            -1
                          )[0]?.arrCName || "N/A"}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Total Fare:</span>
                        <span className="font-semibold text-blue-600">
                          ₹
                          {selectedBooking?.response?.flights?.Fare?.total
                            ?.total || "0"}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <h3 className="font-semibold text-red-900 mb-2">
                      Cancellation Charges
                    </h3>
                    <div className="space-y-2 text-sm text-red-800">
                      <div className="flex justify-between">
                        <span>Cancellation Fee:</span>
                        <span className="font-semibold">₹500 - ₹2,000</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Processing Fee:</span>
                        <span className="font-semibold">₹200</span>
                      </div>
                      <div className="border-t border-red-300 pt-2 mt-2 flex justify-between font-bold">
                        <span>Estimated Refund:</span>
                        <span>
                          ₹
                          {Math.max(
                            0,
                            Number(
                              selectedBooking?.response?.flights?.Fare?.total
                                ?.total || 0
                            ) - 2000 || 0
                          )}
                          {" - "}₹
                          {Math.max(
                            0,
                            Number(
                              selectedBooking?.response?.flights?.Fare?.total
                                ?.total || 0
                            ) - 500 || 0
                          )}
                        </span>
                      </div>
                      <p className="text-xs mt-2 text-red-700">
                        * Final charges may vary based on airline policy and
                        cancellation timing. Refund will be processed within
                        7-14 business days.
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-3 pt-4">
                    <button
                      onClick={() => {
                        setShowCancelModal(false);
                        setSelectedBooking(null);
                      }}
                      className="flex-1 px-6 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors font-medium"
                    >
                      Keep Booking
                    </button>
                    <button
                      onClick={confirmCancelBooking}
                      disabled={actionLoadingId !== null}
                      className="flex-1 px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {actionLoadingId !== null
                        ? "Cancelling..."
                        : "Confirm Cancellation"}
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Reschedule Confirmation Modal */}
      <AnimatePresence>
        {showRescheduleModal && selectedBooking && (
          <motion.div
            className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => {
              setShowRescheduleModal(false);
              setSelectedBooking(null);
            }}
          >
            <motion.div
              className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto"
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="bg-yellow-100 p-3 rounded-full">
                      <FaSync className="text-yellow-600 text-xl" />
                    </div>
                    <h2 className="text-2xl font-bold text-gray-900">
                      Confirm Reschedule
                    </h2>
                  </div>
                  <button
                    onClick={() => {
                      setShowRescheduleModal(false);
                      setSelectedBooking(null);
                    }}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <FaTimes className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <p className="text-sm text-blue-800">
                      <strong>Note:</strong> Rescheduling your flight may incur
                      additional charges based on fare difference and airline
                      policy.
                    </p>
                  </div>

                  <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                    <h3 className="font-semibold text-gray-900">
                      Current Booking Details
                    </h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">
                          Booking Reference:
                        </span>
                        <span className="font-semibold">
                          {selectedBooking.refID || "N/A"}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Current Route:</span>
                        <span className="font-semibold">
                          {selectedBooking?.response?.flights?.Flights
                            ?.Onward?.[0]?.depCName || "N/A"}{" "}
                          →{" "}
                          {selectedBooking?.response?.flights?.Flights?.Onward?.slice(
                            -1
                          )[0]?.arrCName || "N/A"}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Current Date:</span>
                        <span className="font-semibold">
                          {(() => {
                            const firstFlight =
                              selectedBooking?.response?.flights?.Flights
                                ?.Onward?.[0];
                            if (firstFlight?.depDate) {
                              const formatted = formatDateTime(
                                firstFlight.depDate
                              );
                              return formatted.date;
                            }
                            return "N/A";
                          })()}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Total Fare:</span>
                        <span className="font-semibold text-blue-600">
                          ₹
                          {selectedBooking?.response?.flights?.Fare?.total
                            ?.total || "0"}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Reschedule Form */}
                  <div className="bg-white border border-gray-200 rounded-lg p-4 space-y-4">
                    <h3 className="font-semibold text-gray-900">
                      Reschedule Information
                    </h3>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        New Travel Date <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="date"
                        value={rescheduleFormData.newDate}
                        onChange={(e) =>
                          setRescheduleFormData({
                            ...rescheduleFormData,
                            newDate: e.target.value,
                          })
                        }
                        min={new Date().toISOString().split("T")[0]}
                        className="w-full px-4 py-2 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 outline-none"
                        required
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        Please select a date after today
                      </p>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Reason for Rescheduling (Optional)
                      </label>
                      <textarea
                        value={rescheduleFormData.reason}
                        onChange={(e) =>
                          setRescheduleFormData({
                            ...rescheduleFormData,
                            reason: e.target.value,
                          })
                        }
                        placeholder="Please provide a reason for rescheduling..."
                        rows={3}
                        className="w-full px-4 py-2 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 outline-none resize-none"
                      />
                    </div>
                  </div>

                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <h3 className="font-semibold text-yellow-900 mb-2">
                      Reschedule Charges
                    </h3>
                    <div className="space-y-2 text-sm text-yellow-800">
                      <div className="flex justify-between">
                        <span>Reschedule Fee:</span>
                        <span className="font-semibold">₹500 - ₹1,500</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Fare Difference:</span>
                        <span className="font-semibold">As per new flight</span>
                      </div>
                      <p className="text-xs mt-2 text-yellow-700">
                        * Charges may vary based on airline policy, fare type,
                        and availability. Final charges will be calculated based
                        on the new flight selected.
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-3 pt-4">
                    <button
                      onClick={() => {
                        setShowRescheduleModal(false);
                        setSelectedBooking(null);
                        setRescheduleFormData({ newDate: "", reason: "" });
                      }}
                      className="flex-1 px-6 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors font-medium"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={confirmRescheduleBooking}
                      disabled={
                        actionLoadingId !== null || !rescheduleFormData.newDate
                      }
                      className="flex-1 px-6 py-3 bg-yellow-500 text-white rounded-lg hover:bg-yellow-600 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {actionLoadingId !== null
                        ? "Processing..."
                        : "Confirm Reschedule"}
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};

export default Bookings;
