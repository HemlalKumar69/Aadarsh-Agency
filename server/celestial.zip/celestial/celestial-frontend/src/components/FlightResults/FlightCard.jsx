import { motion } from "framer-motion";
import FlightDetails from "./FlightDetails";
import { 
  getSegments, 
  getStopsText, 
  getTotalDurationMinutes, 
  minutesToHm,
  formatApiDateTime 
} from "../../utils/flightUtils";

const FlightCard = ({
  flight,
  index,
  tripType,
  expandedFlights,
  toggleFlightDetails,
  setSelectedFlightForPrice,
  setShowPriceModal,
  verifyFlightPrice,
  statusRefdId,
}) => {
  const onwardSegments = getSegments(flight.Flights?.Onward);
  const firstSegment = onwardSegments[0];
  const lastSegment = onwardSegments[onwardSegments.length - 1];

  const handleViewPrices = async () => {
    try {
      console.log("View Prices clicked for flight:", flight);
      // Set the selected flight first
      setSelectedFlightForPrice(flight);
      // Then show the modal immediately
      setShowPriceModal(true);
      
      // Then verify the price
      if (flight?.Flights?.Onward[0]?.flightID && statusRefdId) {
        console.log("Verifying price for flight ID:", flight.Flights.Onward[0].flightID);
        await verifyFlightPrice(
          flight.Flights.Onward[0].flightID,
          statusRefdId
        );
      } else {
        console.warn("Missing flight ID or statusRefdId");
      }
    } catch (err) {
      console.error("Price verification error", err);
    }
  };

  return (
    <motion.div
      className="bg-white border border-gray-200 rounded-xl p-4 sm:p-6 shadow-lg hover:shadow-xl transition-all duration-300"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
    >
      <FlightHeader
        flight={flight}
        firstSegment={firstSegment}
        lastSegment={lastSegment}
        tripType={tripType}
        onViewPrices={handleViewPrices}
      />
      
      <FlightBody
        flight={flight}
        tripType={tripType}
      />
      
      <FlightFooter
        index={index}
        expandedFlights={expandedFlights}
        toggleFlightDetails={toggleFlightDetails}
      />

      <FlightDetails
        flight={flight}
        index={index}
        expandedFlights={expandedFlights}
        tripType={tripType}
      />
    </motion.div>
  );
};

const FlightHeader = ({
  flight,
  firstSegment,
  lastSegment,
  tripType,
  onViewPrices,
}) => (
  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between w-full gap-4">
    {/* Left Section: Airline Info */}
    <div className="flex items-center gap-4 flex-1">
      <div className="flex flex-col">
        <div className="font-semibold text-gray-900 md:text-2xl text-lg">
          {firstSegment?.airName || "N/A"}
        </div>
        <div className="text-sm text-gray-600">
          <span className="font-semibold">Flight No: </span>
          {firstSegment?.flightNo || "N/A"}
        </div>

        {/* Departure Date */}
        <div className="mt-2">
          <div className="text-sm text-gray-600">
            Departure Date:{" "}
            {formatApiDateTime(firstSegment?.depDate)?.split(",")[0] || "N/A"}
          </div>
        </div>

        {/* Arrival Date */}
        <div className="mt-1">
          <div className="text-sm text-gray-600">
            Arrival Date:{" "}
            {formatApiDateTime(firstSegment?.arrDate)?.split(",")[0] || "N/A"}
          </div>
        </div>

        {/* Return Flight Dates (if round trip) */}
        {tripType === 1 && flight.Flights?.Return && (
          <>
            <div className="mt-3 pt-2 border-t border-gray-200">
              <div className="text-xs text-gray-500">
                Return Departure Date
              </div>
              <div className="text-sm text-gray-600">
                {formatApiDateTime(getSegments(flight.Flights?.Return)[0]?.depDate)?.split(",")[0] || "N/A"}
              </div>
            </div>
            <div className="mt-1">
              <div className="text-xs text-gray-500">
                Return Arrival Date
              </div>
              <div className="text-sm text-gray-600">
                {formatApiDateTime(getSegments(flight.Flights?.Return)[0]?.arrDate)?.split(",")[0] || "N/A"}
              </div>
            </div>
          </>
        )}
      </div>
    </div>

    {/* Middle Section: Flight Details */}
    <div className="flex items-center justify-center gap-4 lg:gap-8 flex-2">
      {/* Departure */}
      <div className="text-center">
        <div className="text-2xl font-bold text-gray-900">
          {formatApiDateTime(firstSegment?.depDate)
            ?.split(",")[1]
            ?.trim() || "N/A"}
        </div>
        <div className="text-sm text-gray-600 mt-1">
          {firstSegment?.depCName || "N/A"}
        </div>
        <div className="text-xs text-gray-500 mt-1">
          Terminal: T{firstSegment?.depTer || "N/A"}
        </div>
      </div>

      {/* Duration & Stops */}
      <div className="text-center">
        <div className="text-sm text-gray-600 mb-1">
          {minutesToHm(getTotalDurationMinutes(flight.Flights?.Onward))}
        </div>
        <div className="w-16 h-0.5 bg-teal-500 mx-auto mb-1"></div>
        <div className="text-xs text-gray-500">
          {getStopsText(flight.Flights?.Onward)}
        </div>
      </div>

      {/* Arrival */}
      <div className="text-center">
        <div className="text-2xl font-bold text-gray-900">
          {formatApiDateTime(lastSegment?.arrDate)
            ?.split(",")[1]
            ?.trim() || "N/A"}
        </div>
        <div className="text-sm text-gray-600 mt-1">
          {lastSegment?.arrCName || "N/A"}
        </div>
        <div className="text-xs text-gray-500 mt-1">
          Terminal: T{lastSegment?.arrTer || "N/A"}
        </div>
      </div>
    </div>

    {/* Right Section: Price & Actions */}
    <div className="text-center lg:text-right flex-1">
      <div className="text-2xl font-bold text-gray-900">
        ₹{flight.Fare?.total?.total || "N/A"}
      </div>
      <div className="text-sm text-gray-500 mb-2">
        per adult
      </div>
      <button
        onClick={onViewPrices}
        className="bg-blue-100 border-2 border-blue-300 text-blue-700 px-4 py-2 rounded-lg font-semibold hover:bg-blue-200 transition-colors duration-200 mb-3 w-full"
      >
        VIEW PRICES
      </button>
    </div>
  </div>
);

const FlightBody = ({
  flight,
  tripType,
}) => (
  <>
    {/* Return Flight (if round trip) */}
    {tripType === 1 && flight.Flights?.Return && (
      <div className="flex items-center justify-center gap-4 lg:gap-8 flex-2 mt-4 pt-4 border-t border-gray-100">
        {/* Return Departure */}
        <div className="text-center">
          <div className="text-2xl font-bold text-gray-900">
            {formatApiDateTime(getSegments(flight.Flights?.Return)[0]?.depDate)
              ?.split(",")[1]
              ?.trim() || "N/A"}
          </div>
          <div className="text-sm text-gray-600 mt-1">
            {getSegments(flight.Flights?.Return)[0]?.depCName || "N/A"}
          </div>
          <div className="text-xs text-gray-500 mt-1">
            Terminal: T{getSegments(flight.Flights?.Return)[0]?.depTer || "N/A"}
          </div>
        </div>

        {/* Return Flight Duration & Stops */}
        <div className="text-center">
          <div className="text-sm text-gray-600 mb-1">
            {minutesToHm(getTotalDurationMinutes(flight.Flights?.Return))}
          </div>
          <div className="w-16 h-0.5 bg-teal-500 mx-auto mb-1"></div>
          <div className="text-xs text-gray-500">
            {getStopsText(flight.Flights?.Return)}
          </div>
        </div>

        {/* Return Arrival */}
        <div className="text-center">
          <div className="text-2xl font-bold text-gray-900">
            {formatApiDateTime(getSegments(flight.Flights?.Return)[0]?.arrDate)
              ?.split(",")[1]
              ?.trim() || "N/A"}
          </div>
          <div className="text-sm text-gray-600 mt-1">
            {getSegments(flight.Flights?.Return)[0]?.arrCName || "N/A"}
          </div>
          <div className="text-xs text-gray-500 mt-1">
            Terminal: T{getSegments(flight.Flights?.Return)[0]?.arrTer || "N/A"}
          </div>
        </div>
      </div>
    )}
  </>
);

const FlightFooter = ({
  index,
  expandedFlights,
  toggleFlightDetails,
}) => (
  <div className="flex justify-between items-center">
    <div
      className="text-blue-600 text-sm cursor-pointer hover:underline"
      onClick={() => toggleFlightDetails(index)}
    >
      {expandedFlights[index]
        ? "Hide Flight Details"
        : "View Flight Details"}
    </div>
  </div>
);

export default FlightCard;