import { 
    getSegments, 
    getStopsText, 
    getTotalDurationMinutes, 
    minutesToHm,
    formatApiDateTime 
  } from "../../utils/flightUtils";
  
  const FlightDetails = ({
    flight,
    index,
    expandedFlights,
    tripType,
  }) => {
    if (!expandedFlights[index]) return null;
  
    const firstSegment = getSegments(flight.Flights?.Onward)[0];
    const lastSegment = getSegments(flight.Flights?.Onward).slice(-1)[0];
  
    return (
      <div className="mt-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Flight Information */}
          <div>
            <h4 className="font-semibold text-gray-900 mb-3">
              Flight Information
            </h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Airline:</span>
                <span className="font-medium">
                  {firstSegment?.airName || "N/A"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Flight Number:</span>
                <span className="font-medium">
                  {firstSegment?.flightNo || "N/A"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Aircraft Code:</span>
                <span className="font-medium">
                  {firstSegment?.airCode || "N/A"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Duration:</span>
                <span className="font-medium">
                  {minutesToHm(getTotalDurationMinutes(flight.Flights?.Onward))}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Stops:</span>
                <span className="font-medium">
                  {getStopsText(flight.Flights?.Onward)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Cabin Class:</span>
                <span className="font-medium">
                  {firstSegment?.cabin || "N/A"}
                </span>
              </div>
            </div>
          </div>
  
          {/* Route Information */}
          <div>
            <h4 className="font-semibold text-gray-900 mb-3">
              Route Information
            </h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Departure:</span>
                <span className="font-medium">
                  {firstSegment?.depCName || "N/A"} ({firstSegment?.depCode || "N/A"})
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Arrival:</span>
                <span className="font-medium">
                  {lastSegment?.arrCName || "N/A"} ({lastSegment?.arrCode || "N/A"})
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Departure Time:</span>
                <span className="font-medium">
                  {formatApiDateTime(firstSegment?.depDate) || "N/A"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Arrival Time:</span>
                <span className="font-medium">
                  {formatApiDateTime(lastSegment?.arrDate) || "N/A"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Departure Terminal:</span>
                <span className="font-medium">
                  T{firstSegment?.depTer || "N/A"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Arrival Terminal:</span>
                <span className="font-medium">
                  T{lastSegment?.arrTer || "N/A"}
                </span>
              </div>
            </div>
          </div>
  
          {/* Fare Information */}
          <div>
            <h4 className="font-semibold text-gray-900 mb-3">
              Fare Information
            </h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Base Fare:</span>
                <span className="font-medium">
                  ₹{flight.Fare?.total?.base || "N/A"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Taxes & Fees:</span>
                <span className="font-medium">
                  ₹{flight.Fare?.total?.tax || "N/A"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Total Price:</span>
                <span className="font-medium text-lg">
                  ₹{flight.Fare?.total?.total || "N/A"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Refundable:</span>
                <span className="font-medium">
                  {flight.Flights?.refundable === "P"
                    ? "Partially Refundable"
                    : "Non-Refundable"}
                </span>
              </div>
            </div>
          </div>
  
          {/* Baggage Information */}
          <div>
            <h4 className="font-semibold text-gray-900 mb-3">
              Baggage Information
            </h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Cabin Baggage:</span>
                <span className="font-medium">
                  {flight.Flights?.bagCbin || "N/A"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Check-in Baggage:</span>
                <span className="font-medium">
                  {flight.Flights?.bagCkin || "N/A"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Seat Selection:</span>
                <span className="font-medium">
                  {flight.Flights?.seats || "Not Available"}
                </span>
              </div>
            </div>
          </div>
        </div>
  
        {/* Return Flight Details (if round trip) */}
        {tripType === 1 && flight.Flights?.Return && (
          <div className="mt-6 pt-4 border-t border-gray-200">
            <h4 className="font-semibold text-gray-900 mb-3">
              Return Flight Details
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Airline:</span>
                    <span className="font-medium">
                      {getSegments(flight.Flights?.Return)[0]?.airName || "N/A"}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Flight Number:</span>
                    <span className="font-medium">
                      {getSegments(flight.Flights?.Return)[0]?.flightNo || "N/A"}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Duration:</span>
                    <span className="font-medium">
                      {minutesToHm(getTotalDurationMinutes(flight.Flights?.Return))}
                    </span>
                  </div>
                </div>
              </div>
              <div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Departure:</span>
                    <span className="font-medium">
                      {getSegments(flight.Flights?.Return)[0]?.depCName || "N/A"}{" "}
                      ({getSegments(flight.Flights?.Return)[0]?.depCode || "N/A"})
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Arrival:</span>
                    <span className="font-medium">
                      {getSegments(flight.Flights?.Return)[0]?.arrCName || "N/A"}{" "}
                      ({getSegments(flight.Flights?.Return)[0]?.arrCode || "N/A"})
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Departure Time:</span>
                    <span className="font-medium">
                      {formatApiDateTime(getSegments(flight.Flights?.Return)[0]?.depDate) || "N/A"}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Arrival Time:</span>
                    <span className="font-medium">
                      {formatApiDateTime(getSegments(flight.Flights?.Return)[0]?.arrDate) || "N/A"}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };
  
  export default FlightDetails;