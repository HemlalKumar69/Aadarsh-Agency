import { motion } from "framer-motion";
import { FaPlane, FaTimes } from "react-icons/fa";
import FlightCard from "./FlightCard";

const FlightResults = ({
  showResults,
  setShowResults,
  searchResults,
  pagedResults,
  currentPage,
  setCurrentPage,
  totalPages,
  pageSize,
  tripType,
  expandedFlights,
  toggleFlightDetails,
  setSelectedFlightForPrice,
  setShowPriceModal,
  verifyFlightPrice,
  statusRefdId,
}) => {
  if (!showResults) return null;

  return (
    <div className="bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <ResultsHeader 
          searchResults={searchResults} 
          setShowResults={setShowResults} 
        />
        
        {searchResults.length === 0 ? (
          <NoResults />
        ) : (
          <ResultsList
            pagedResults={pagedResults}
            tripType={tripType}
            expandedFlights={expandedFlights}
            toggleFlightDetails={toggleFlightDetails}
            setSelectedFlightForPrice={setSelectedFlightForPrice}
            setShowPriceModal={setShowPriceModal}
            verifyFlightPrice={verifyFlightPrice}
            statusRefdId={statusRefdId}
          />
        )}

        <Pagination
          searchResults={searchResults}
          pageSize={pageSize}
          currentPage={currentPage}
          setCurrentPage={setCurrentPage}
          totalPages={totalPages}
        />
      </div>
    </div>
  );
};

const ResultsHeader = ({ searchResults, setShowResults }) => (
  <div className="flex items-center justify-between mb-6">
    <h2 className="text-2xl font-bold text-gray-900">
      Available Flights ({searchResults.length} found)
    </h2>
    <button
      onClick={() => setShowResults(false)}
      className="text-gray-500 hover:text-gray-700 p-2"
    >
      <FaTimes className="text-xl" />
    </button>
  </div>
);

const NoResults = () => (
  <div className="text-center py-8">
    <FaPlane className="text-4xl text-gray-400 mx-auto mb-4" />
    <h3 className="text-xl font-semibold text-gray-600 mb-2">
      No Flights Found
    </h3>
    <p className="text-gray-500">
      Try adjusting your search criteria or dates.
    </p>
  </div>
);

const ResultsList = ({
  pagedResults,
  tripType,
  expandedFlights,
  toggleFlightDetails,
  setSelectedFlightForPrice,
  setShowPriceModal,
  verifyFlightPrice,
  statusRefdId,
}) => (
  <div className="space-y-4">
    {pagedResults.map((flight, index) => (
      <FlightCard
        key={index}
        flight={flight}
        index={index}
        tripType={tripType}
        expandedFlights={expandedFlights}
        toggleFlightDetails={toggleFlightDetails}
        setSelectedFlightForPrice={setSelectedFlightForPrice}
        setShowPriceModal={setShowPriceModal}
        verifyFlightPrice={verifyFlightPrice}
        statusRefdId={statusRefdId}
      />
    ))}
  </div>
);

const Pagination = ({
  searchResults,
  pageSize,
  currentPage,
  setCurrentPage,
  totalPages,
}) => {
  if (searchResults.length <= pageSize) return null;

  return (
    <div className="flex items-center justify-center gap-1 pt-4 flex-wrap">
      <button
        className="px-3 py-1 border rounded disabled:opacity-50 bg-white hover:bg-gray-50"
        onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
        disabled={currentPage === 1}
      >
        Prev
      </button>
      {Array.from({ length: totalPages }).map((_, i) => (
        <button
          key={i}
          className={`px-3 py-1 border rounded min-w-[40px] text-center ${
            currentPage === i + 1
              ? "bg-blue-600 text-white border-blue-600"
              : "bg-white hover:bg-gray-50"
          }`}
          onClick={() => setCurrentPage(i + 1)}
        >
          {i + 1}
        </button>
      ))}
      <button
        className="px-3 py-1 border rounded disabled:opacity-50 bg-white hover:bg-gray-50"
        onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
        disabled={currentPage === totalPages}
      >
        Next
      </button>
    </div>
  );
};

export default FlightResults;