import { forwardRef } from "react";
import { motion } from "framer-motion";
import {
  FaMapMarkerAlt,
  FaPlane,
  FaCalendarAlt,
  FaExchangeAlt,
  FaSearch,
  FaSpinner,
  FaChevronDown,
  FaUsers,
} from "react-icons/fa";

const SearchForm = ({
  formData,
  setFormData,
  tripType,
  setTripType,
  airports,
  airportsByServiceType,
  filteredFromAirports,
  setFilteredFromAirports,
  filteredToAirports,
  setFilteredToAirports,
  dropdowns,
  setDropdowns,
  isLoading,
  handleSearch,
  handleFromInputChange,
  handleToInputChange,
  filterAirports,
  toggleDropdown,
  selectOption,
  swapLocations,
  handleInputChange,
  getTodayDate,
  getMinReturnDate,
  travellersRef,
  fromRef,
  toRef,
  serviceRef,
  fareRef,
  isLoadingLocations,
}) => {
  return (
    <motion.div
      className="w-full max-w-6xl bg-white rounded-3xl shadow-2xl p-6 sm:p-9 relative border-2 border-gray-100"
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, delay: 0.3 }}
      whileHover={{ scale: 1.01 }}
    >
      {/* Dashed border effect */}
      <div className="absolute left-0 top-0 bottom-0 w-1 sm:w-2 border-l-4 border-dashed border-gray-400"></div>
      <div className="absolute right-0 top-0 bottom-0 w-1 sm:w-2 border-r-4 border-dashed border-gray-400"></div>

      {/* Trip Type Tabs and Service/Fare Type */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4 sm:gap-0">
        <TripTypeTabs tripType={tripType} setTripType={setTripType} />
        <ServiceFareTravellers
          formData={formData}
          setFormData={setFormData}
          dropdowns={dropdowns}
          setDropdowns={setDropdowns}
          travellersRef={travellersRef}
          serviceRef={serviceRef}
          fareRef={fareRef}
          toggleDropdown={toggleDropdown}
        />
      </div>

      <form onSubmit={handleSearch}>
        <div className="flex flex-col sm:flex-row flex-wrap items-start sm:items-end gap-4">
          <LocationInputs
            formData={formData}
            fromRef={fromRef}
            toRef={toRef}
            dropdowns={dropdowns}
            setDropdowns={setDropdowns}
            filteredFromAirports={filteredFromAirports}
            filteredToAirports={filteredToAirports}
            handleFromInputChange={handleFromInputChange}
            handleToInputChange={handleToInputChange}
            selectOption={selectOption}
            swapLocations={swapLocations}
            isLoadingLocations={isLoadingLocations}
          />

          <DateInputs
            formData={formData}
            tripType={tripType}
            handleInputChange={handleInputChange}
            getTodayDate={getTodayDate}
            getMinReturnDate={getMinReturnDate}
          />
        </div>

        <SearchButton isLoading={isLoading} />
      </form>
    </motion.div>
  );
};

const TripTypeTabs = ({ tripType, setTripType }) => (
  <div className="flex flex-wrap sm:flex-nowrap space-x-2">
    {[
      { id: 0, label: "One Way" },
      { id: 1, label: "Round Trip" },
    ].map((tab) => (
      <motion.button
        key={tab.id}
        onClick={() => setTripType(tab?.id)}
        className={`px-5 py-2 rounded-xl font-semibold transition-all duration-200 text-sm sm:text-base ${
          tripType === tab.id
            ? "bg-gray-800 text-white shadow-lg"
            : "bg-gray-100 text-gray-600 hover:bg-gray-200"
        }`}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        {tab.label}
      </motion.button>
    ))}
  </div>
);

const ServiceFareTravellers = ({
  formData,
  setFormData,
  dropdowns,
  setDropdowns,
  travellersRef,
  serviceRef,
  fareRef,
  toggleDropdown,
}) => (
  <div className="flex flex-col sm:flex-row flex-wrap items-start sm:items-end gap-4">
    <DropdownSelect
      ref={serviceRef}
      label="Service Type"
      value={formData.serType === 1 ? "Domestic" : "International"}
      isOpen={dropdowns.service}
      onToggle={() => toggleDropdown("service")}
      options={[
        {
          value: 1,
          label: "Domestic",
          description: "Within India",
        },
        {
          value: 2,
          label: "International",
          description: "Outside India",
        },
      ]}
      onSelect={(value) => setFormData((prev) => ({ ...prev, serType: value }))}
    />

    <DropdownSelect
      ref={fareRef}
      label="Fare Type"
      value={
        formData.fareType === "A"
          ? "All"
          : formData.fareType === "S"
          ? "Student"
          : formData.fareType === "C"
          ? "Senior Citizen"
          : "Defence"
      }
      isOpen={dropdowns.fare}
      onToggle={() => toggleDropdown("fare")}
      options={[
        {
          value: "A",
          label: "All",
          description: "Regular fares",
        },
        {
          value: "S",
          label: "Student",
          description: "Students discounts",
        },
        {
          value: "C",
          label: "Senior Citizen",
          description: "Senior citizen benefits",
        },
        {
          value: "D",
          label: "Defence",
          description: "Defence personal rate",
        },
      ]}
      onSelect={(value) => setFormData((prev) => ({ ...prev, fareType: value }))}
    />

    <TravellersDropdown
      ref={travellersRef}
      formData={formData}
      setFormData={setFormData}
      isOpen={dropdowns.travellers}
      onToggle={() => toggleDropdown("travellers")}
    />
  </div>
);

const DropdownSelect = forwardRef(
  ({ label, value, isOpen, onToggle, options, onSelect }, ref) => (
    <motion.div
      className="relative flex-1 w-full"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.7 }}
      ref={ref}
    >
      <label className="block text-sm font-semibold text-gray-700 mb-2">
        {label}
      </label>
      <div className="relative">
        <input
          type="text"
          value={value}
          onClick={onToggle}
          className="w-full pl-4 pr-4 py-2 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-gray-50 text-gray-700 cursor-pointer"
          readOnly
        />
        <FaChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400" />

        {isOpen && (
          <div className="absolute top-full left-0 right-0 mt-2 bg-white border-2 border-gray-200 rounded-xl shadow-lg z-50 max-h-60 overflow-y-auto">
            {options.map((option, index) => (
              <div
                key={index}
                className="px-4 py-2 hover:bg-blue-50 cursor-pointer text-sm text-gray-700 border-b border-gray-100 last:border-b-0"
                onClick={() => {
                  onSelect(option.value);
                  onToggle();
                }}
              >
                <div className="font-semibold">{option.label}</div>
                <div className="text-xs text-gray-500">{option.description}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </motion.div>
  )
);

const TravellersDropdown = forwardRef(
  ({ formData, setFormData, isOpen, onToggle }, ref) => (
    <motion.div
      ref={ref}
      className="relative flex-[2] w-full"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.9 }}
    >
      <label className="block text-sm font-semibold text-gray-700 mb-2">
        Travellers & Class
      </label>
      <div className="relative">
        <button
          type="button"
          onClick={onToggle}
          className="w-full flex items-center justify-between px-4 py-2.5 border-2 border-gray-200 rounded-xl bg-gray-50 text-gray-700 cursor-pointer hover:bg-gray-100 transition-all duration-200"
        >
          <span className="text-sm whitespace-nowrap">
            {formData.adults} Adult{formData.adults > 1 ? "s" : ""},{" "}
            {formData.children} Child{formData.children > 1 ? "ren" : ""},{" "}
            {formData.infants} Infant{formData.infants > 1 ? "s" : ""} •{" "}
            {formData.cabin === "E"
              ? "Economy"
              : formData.cabin === "P"
              ? "Premium Economy"
              : formData.cabin === "B"
              ? "Business"
              : "First Class"}
          </span>
          <FaChevronDown
            className={`text-gray-400 transition-transform duration-200 ${
              isOpen ? "rotate-180" : ""
            }`}
          />
        </button>

        {isOpen && (
          <TravellersOptions formData={formData} setFormData={setFormData} />
        )}
      </div>
    </motion.div>
  )
);

const TravellersOptions = ({ formData, setFormData }) => (
  <div className="absolute top-full right-0 mt-1 bg-white border border-gray-300 rounded-lg shadow-lg z-50 p-3 w-fit min-w-[280px]">
    <PassengerSection
      title="ADULTS (12y +)"
      count={formData.adults}
      max={9}
      onChange={(newAdults) => {
        const newChildren = Math.min(formData.children, 9 - newAdults);
        const newInfants = Math.min(formData.infants, newAdults, 4);
        setFormData((v) => ({
          ...v,
          adults: newAdults,
          children: newChildren,
          infants: newInfants,
        }));
      }}
    />

    <PassengerSection
      title="CHILDREN (2y - 12y)"
      count={formData.children}
      max={Math.max(0, 9 - formData.adults)}
      onChange={(newChildren) => {
        setFormData((v) => ({
          ...v,
          children: newChildren,
        }));
      }}
    />

    <PassengerSection
      title="INFANTS (below 2y)"
      count={formData.infants}
      max={Math.min(formData.adults, 4)}
      onChange={(newInfants) => {
        setFormData((v) => ({
          ...v,
          infants: newInfants,
        }));
      }}
    />

    <CabinClassSection formData={formData} setFormData={setFormData} />
  </div>
);

const PassengerSection = ({ title, count, max, onChange }) => (
  <div className="mb-3">
    <h4 className="text-xs font-semibold text-gray-700 mb-2">{title}</h4>
    <div className="flex flex-wrap gap-1">
      {[1, 2, 3, 4, 5, 6, 7, 8, 9]
        .filter((num) => num <= max)
        .map((num) => (
          <button
            key={num}
            type="button"
            onClick={() => onChange(num)}
            className={`px-2 py-1 rounded text-xs font-medium transition-all duration-200 ${
              count === num
                ? "bg-blue-600 text-white shadow-md"
                : "bg-gray-100 text-gray-600 hover:bg-gray-200"
            }`}
          >
            {num}
          </button>
        ))}
    </div>
  </div>
);

const CabinClassSection = ({ formData, setFormData }) => (
  <div>
    <h4 className="text-xs font-semibold text-gray-700 mb-2">TRAVEL CLASS</h4>
    <div className="flex flex-wrap gap-1">
      {[
        { value: "E", label: "Economy" },
        { value: "P", label: "Premium" },
        { value: "B", label: "Business" },
        { value: "F", label: "First" },
      ].map((cabin) => (
        <button
          key={cabin.value}
          type="button"
          onClick={() => setFormData((v) => ({ ...v, cabin: cabin.value }))}
          className={`px-2 py-1 rounded text-xs font-medium transition-all duration-200 ${
            formData.cabin === cabin.value
              ? "bg-blue-600 text-white shadow-md"
              : "bg-gray-100 text-gray-600 hover:bg-gray-200"
          }`}
        >
          {cabin.label}
        </button>
      ))}
    </div>
  </div>
);

const LocationInputs = ({
  formData,
  fromRef,
  toRef,
  dropdowns,
  setDropdowns,
  filteredFromAirports,
  filteredToAirports,
  handleFromInputChange,
  handleToInputChange,
  selectOption,
  swapLocations,
  isLoadingLocations,
}) => (
  <>
    <LocationInput
      ref={fromRef}
      label="From"
      value={formData.from}
      onChange={handleFromInputChange}
      isOpen={dropdowns.from}
      onFocus={() => {
        // Just show the dropdown if we have filtered results
        setDropdowns((prev) => ({ 
          ...prev, 
          from: filteredFromAirports.length > 0 && formData.from.trim().length > 0 
        }));
      }}
      filteredAirports={filteredFromAirports}
      onSelect={(value) => selectOption("from", value)}
      icon={FaMapMarkerAlt}
      placeholder="Search by city, airport name, or code"
      isLoadingLocations={isLoadingLocations}
      setDropdowns={setDropdowns}
    />

    <SwapButton onSwap={swapLocations} />

    <LocationInput
      ref={toRef}
      label="To"
      value={formData.to}
      onChange={handleToInputChange}
      isOpen={dropdowns.to}
      onFocus={() => {
        // Just show the dropdown if we have filtered results
        setDropdowns((prev) => ({ 
          ...prev, 
          to: filteredToAirports.length > 0 && formData.to.trim().length > 0 
        }));
      }}
      filteredAirports={filteredToAirports}
      onSelect={(value) => selectOption("to", value)}
      icon={FaPlane}
      placeholder="Search by city, airport name, or code"
      isLoadingLocations={isLoadingLocations}
      setDropdowns={setDropdowns}
    />
  </>
);

const LocationInput = forwardRef(
  (
    {
      label,
      value,
      onChange,
      isOpen,
      onFocus,
      filteredAirports,
      onSelect,
      icon: Icon,
      placeholder,
      isLoadingLocations,
      setDropdowns,
    },
    ref
  ) => (
    <motion.div
      className="relative flex-1 w-full"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.7 }}
      ref={ref}
    >
      <label className="block text-sm font-semibold text-gray-700 mb-2">
        {label} <span className="text-red-500">*</span>
      </label>
      <div className="relative">
        <Icon className="absolute left-2 top-1/2 transform -translate-y-1/2 text-blue-600 text-lg" />
        <input
          type="text"
          value={value}
          onChange={onChange}
          onFocus={onFocus}
          placeholder={placeholder}
          className="w-full pl-7 pr-4 py-2 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white text-gray-700"
          required
        />
        <FaChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400" />

        {isOpen && filteredAirports.length > 0 && (
          <LocationDropdown
            airports={filteredAirports}
            onSelect={onSelect}
            onClose={() => setDropdowns((prev) => ({ ...prev, from: false }))}
            isLoadingLocations={isLoadingLocations}
          />
        )}
      </div>
    </motion.div>
  )
);

const LocationDropdown = ({ airports, onSelect, onClose, isLoadingLocations }) => (
  <div className="absolute top-full left-0 right-0 mt-2 bg-white border-2 border-gray-200 rounded-xl shadow-lg z-50 max-h-60 overflow-x-hidden overflow-y-auto">
    {isLoadingLocations ? (
      <div className="px-4 py-2 text-center text-gray-500">
        <FaSpinner className="animate-spin mx-auto mb-2" />
        Loading airports...
      </div>
    ) : airports.length > 0 ? (
      airports.map((location, index) => (
        <div
          key={location.code || index}
          className="px-4 py-2 hover:bg-blue-50 cursor-pointer text-sm text-gray-700 border-b border-gray-100 last:border-b-0"
          onClick={() => {
            const displayValue = `${location.name} (${location.code})`;
            onSelect(displayValue);
            onClose();
          }}
        >
          <div className="font-semibold">
            {location.name} ({location.code})
          </div>
          <div className="text-xs text-gray-500">
            {location.city}, {location.country}
          </div>
        </div>
      ))
    ) : (
      <div className="px-4 py-2 text-center text-gray-500">
        No airports found. Try a different search term.
      </div>
    )}
  </div>
);

const SwapButton = ({ onSwap }) => (
  <motion.div
    className="flex justify-center w-full sm:w-auto"
    initial={{ opacity: 0, scale: 0 }}
    animate={{ opacity: 1, scale: 1 }}
    transition={{ duration: 0.5, delay: 0.8 }}
  >
    <motion.button
      type="button"
      onClick={onSwap}
      className="w-10 h-10 bg-gray-200 hover:bg-gray-300 rounded-full flex items-center justify-center transition-colors duration-200 shadow-lg"
      whileHover={{ scale: 1.1, rotate: 180 }}
      whileTap={{ scale: 0.9 }}
    >
      <FaExchangeAlt className="text-gray-600 text-base" />
    </motion.button>
  </motion.div>
);

const DateInputs = ({
  formData,
  tripType,
  handleInputChange,
  getTodayDate,
  getMinReturnDate,
}) => (
  <>
    <DateInput
      label="Departure Date"
      name="departure"
      value={formData.departure}
      onChange={handleInputChange}
      min={getTodayDate()}
      required
    />

    {tripType === 1 && (
      <DateInput
        label="Return Date"
        name="returnDate"
        value={formData.returnDate}
        onChange={handleInputChange}
        min={getMinReturnDate()}
        required
      />
    )}
  </>
);

const DateInput = ({ label, name, value, onChange, min, required }) => (
  <motion.div
    className="relative flex-1 w-full"
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay: 1.0 }}
  >
    <label className="block text-sm font-semibold text-gray-700 mb-2">
      {label} {required && <span className="text-red-500">*</span>}
    </label>
    <div className="relative">
      <FaCalendarAlt className="absolute left-4 top-1/2 transform -translate-y-1/2 text-blue-600 text-lg" />
      <input
        type="date"
        name={name}
        value={value}
        onChange={onChange}
        min={min}
        className="w-full pl-12 pr-4 py-2 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-gray-50 text-gray-700"
        required={required}
      />
    </div>
  </motion.div>
);

const SearchButton = ({ isLoading }) => (
  <motion.div
    className="flex justify-center sm:justify-end mt-7"
    initial={{ opacity: 0, x: 50 }}
    animate={{ opacity: 1, x: 0 }}
    transition={{ duration: 0.5, delay: 1.1 }}
  >
    <motion.button
      type="submit"
      disabled={isLoading}
      onClick={() => {
        setTimeout(() => {
          const start = window.scrollY;
          const distance = 400;
          const duration = 600;
          const startTime = performance.now();

          const easeInOutQuad = (t) =>
            t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;

          const animateScroll = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const ease = easeInOutQuad(progress);
            window.scrollTo(0, start + distance * ease);

            if (elapsed < duration)
              requestAnimationFrame(animateScroll);
          };

          requestAnimationFrame(animateScroll);
        }, 300);
      }}
      className={`w-full sm:w-auto bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white px-8 py-3 rounded-xl font-semibold flex items-center justify-center space-x-3 transition-all duration-200 shadow-lg hover:shadow-xl ${
        isLoading ? "opacity-75 cursor-not-allowed" : ""
      }`}
      whileHover={!isLoading ? { scale: 1.05 } : {}}
      whileTap={!isLoading ? { scale: 0.95 } : {}}
    >
      {isLoading ? (
        <>
          <FaSpinner className="text-lg animate-spin" />
          <span>Searching Flights...</span>
        </>
      ) : (
        <>
          <span>Find Flights</span>
          <FaSearch className="text-lg" />
        </>
      )}
    </motion.button>
  </motion.div>
);

export default SearchForm;