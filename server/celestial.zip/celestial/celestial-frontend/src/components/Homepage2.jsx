import { useState, useEffect, useCallback, useRef, useMemo } from "react";
import axios from "axios";
import { motion } from "framer-motion";
import { FaPlane, FaExclamationTriangle, FaTimes } from "react-icons/fa";
import { useNavigate, useLocation } from "react-router-dom";
import flighthome from "../assets/flighthome.jpg";
import About from "./About";
import Features from "./Features";
import Price from "./Price";
import SpecialOffer from "./SpecialOffer";
import Services from "./Services";
import Testimonials from "./Testimonials";
import Faq from "./Faq";
import { useSelector, useDispatch } from "react-redux";
import { checkUserLogin } from "../redux/reduxThunk/thunkAuthUser/AuthUser";
import PaymentModal from "./PaymentModal";
import LoginModal from "./LoginModal";

import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

// Components
import SearchForm from "./FlightSearch/SearchForm";
import FlightResults from "./FlightResults/FlightResults";
import PriceModal from "./Modals/PriceModal";
import PassengerForm from "./PassengerForm/PassengerForm";
import BookingSuccessModal from "./Modals/BookingSuccessModal";
import FeedbackModal from "./Modals/FeedbackModal";
import UpdateStorageModal from "./Modals/UpdateStorageModal";

const Homepage2 = () => {
  const API_BASE = import.meta.env.VITE_URL || import.meta.env.VITE_URL2;

  const [airports, setAirports] = useState([]);
  const [filteredFromAirports, setFilteredFromAirports] = useState([]);
  const [filteredToAirports, setFilteredToAirports] = useState([]);

  // ✅ Validation Setup
  const today = new Date();
  const sixtyDaysAgo = new Date(today);
  sixtyDaysAgo.setDate(today.getDate() - 60);
  const twelveYearsAgo = new Date(today);
  twelveYearsAgo.setFullYear(today.getFullYear() - 12);

  const formSchema = z.object({
    mobile: z
      .string()
      .min(1, "Mobile number is required")
      .regex(/^[6-9]\d{9}$/, "Enter a valid 10-digit Indian mobile number"),
    email: z
      .string()
      .min(1, "Email is required")
      .regex(/^[a-zA-Z0-9._%+-]+@gmail\.com$/, "Only Gmail addresses allowed"),
    passengers: z
      .array(
        z.object({
          title: z.string().min(1, "Title required"),
          gender: z.string().min(1, "Gender required"),
          fName: z
            .string()
            .min(1, "First name required")
            .regex(/^[A-Za-z\s]+$/, "Only alphabets allowed"),
          lName: z
            .string()
            .min(1, "Last name required")
            .regex(/^[A-Za-z\s]+$/, "Only alphabets allowed"),
          dob: z
            .string()
            .min(1, "Date of Birth is required")
            .refine((value) => {
              if (!value) return false;
              const dobDate = new Date(value);
              return !isNaN(dobDate.getTime());
            }, "Enter valid DOB"),
          ppNo: z.string().optional(),
          ppIss: z.string().optional(),
          ppExp: z.string().optional(),
          ppNat: z.string().optional(),
        })
      )
      .min(1, "At least one passenger required"),
  });

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(formSchema),
    mode: "onBlur",
    reValidateMode: "onBlur",
  });

  // API Configuration
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const [tripType, setTripType] = useState(0);
  const [statusRefdId, setStatusRefdId] = useState(null);
  const [statusDatas, setStatusDatas] = useState("");
  const [isOpen, setIsOpen] = useState(false);

  void motion;

  const [formData, setFormData] = useState({
    class: "Economy",
    from: "",
    to: "",
    departure: "",
    returnDate: "",
    tripType: tripType,
    adults: 1,
    children: 0,
    infants: 0,
    serType: 1,
    cabin: "E",
    fareType: "A",
  });

  const [dropdowns, setDropdowns] = useState({
    class: false,
    from: false,
    to: false,
    travellers: false,
    service: false,
    fare: false,
  });

  // API Integration States
  const [isLoading, setIsLoading] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;
  const pagedResults = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return searchResults.slice(start, start + pageSize);
  }, [searchResults, currentPage]);
  const totalPages = useMemo(
    () => Math.ceil(searchResults.length / pageSize) || 1,
    [searchResults.length]
  );
  const [error, setError] = useState(null);
  const [showResults, setShowResults] = useState(false);
  const [selectedFlight, setSelectedFlight] = useState(null);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [debugInfo, setDebugInfo] = useState("");
  const [isBooking, setIsBooking] = useState(false);
  const [isPaying, setIsPaying] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [pendingFareForAuth, setPendingFareForAuth] = useState(null);
  const [amount, setAmount] = useState(null);
  const [bookingError, setBookingError] = useState(null);
  const [bookingResult, setBookingResult] = useState(null);
  const [lastSearchPayload, setLastSearchPayload] = useState(null);

  // Price verification modal states
  const [showPriceModal, setShowPriceModal] = useState(false);
  const [selectedFlightForPrice, setSelectedFlightForPrice] = useState(null);
  const [priceOptions, setPriceOptions] = useState([]);
  const [isLoadingPrices, setIsLoadingPrices] = useState(false);
  const [selectedFare, setSelectedFare] = useState(null);
  const [showPassengerForm, setShowPassengerForm] = useState(false);
  const [passengerDetails, setPassengerDetails] = useState([]);
  const [formPassengerData, setFormPassengerData] = useState([
    {
      title: "",
      fName: "",
      lName: "",
      pType: "",
      gender: "",
      dob: "",
      ppNo: "",
      ppIss: "",
      ppExp: "",
      ppNat: "",
    },
  ]);
  const [contactInfo, setContactInfo] = useState({
    mobile: "",
    email: "",
  });
  const [ssrOptions, setSsrOptions] = useState({});
  const [selectedSsr, setSelectedSsr] = useState({});
  const [isLoadingSsr, setIsLoadingSsr] = useState(false);
  const [expandedFlights, setExpandedFlights] = useState({});
  const [availableSeats, setAvailableSeats] = useState([]);
  const [isLoadingSeats, setIsLoadingSeats] = useState(false);
  const [selectedSeats, setSelectedSeats] = useState({});
  const [showBookingSuccess, setShowBookingSuccess] = useState(false);
  const [bookingSuccessData, setBookingSuccessData] = useState(null);
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);
  const [rating, setRating] = useState(0);
  const [feedbackText, setFeedbackText] = useState("");
  const [isSubmittingFeedback, setIsSubmittingFeedback] = useState(false);
  const [showUpdateModal, setShowUpdateModal] = useState(false);

  // Seat Selection Visibility
  const [showSeatSelection, setShowSeatSelection] = useState(false);

  // Mark unused variables to satisfy linter
  void setSelectedFlight;
  void setPassengerDetails;
  void ssrOptions;
  void isLoadingSsr;

  // Dropdown Data States - Now using airports from database
  const [isLoadingLocations, setIsLoadingLocations] = useState(false);

  // Pre-filter airports by service type for better performance
  const airportsByServiceType = useMemo(() => {
    if (airports.length === 0) return { domestic: [], international: [] };

    const domestic = airports.filter((airport) => airport.country === "India");
    const international = airports.filter(
      (airport) => airport.country !== "India"
    );

    return { domestic, international };
  }, [airports]);

  // ✅ Improved filter function for airports
  const filterAirports = (searchTerm, airportList) => {
    if (!searchTerm || !searchTerm.trim()) {
      return airportList.slice(0, 10); // Limit initial results for performance
    }

    const lowerSearch = searchTerm.toLowerCase().trim();
    
    return airportList.filter(airport => {
      const code = airport.code?.toLowerCase() || '';
      const city = airport.city?.toLowerCase() || '';
      const name = airport.name?.toLowerCase() || '';
      const country = airport.country?.toLowerCase() || '';

      // Check if any field starts with the search term (highest priority)
      if (
        city.startsWith(lowerSearch) ||
        name.startsWith(lowerSearch) ||
        code.startsWith(lowerSearch) ||
        country.startsWith(lowerSearch)
      ) {
        return true;
      }

      // Then check if any field contains the search term
      if (
        city.includes(lowerSearch) ||
        name.includes(lowerSearch) ||
        code.includes(lowerSearch) ||
        country.includes(lowerSearch)
      ) {
        return true;
      }

      return false;
    }).slice(0, 10); // Limit results for performance
  };

  // ✅ Improved From input change handler
  const handleFromInputChange = (e) => {
    const value = e.target.value;
    
    setFormData((prev) => ({
      ...prev,
      from: value,
    }));

    // Filter airports based on current service type
    const airportList = formData.serType === 1 
      ? airportsByServiceType.domestic 
      : airportsByServiceType.international;

    const filtered = filterAirports(value, airportList);
    setFilteredFromAirports(filtered);
    
    // Show dropdown if there are results and search term is not empty
    setDropdowns((prevDropdowns) => ({ 
      ...prevDropdowns, 
      from: value.trim().length > 0 && filtered.length > 0 
    }));
  };

  // ✅ Improved To input change handler
  const handleToInputChange = (e) => {
    const value = e.target.value;
    
    setFormData((prev) => ({
      ...prev,
      to: value,
    }));

    // Filter airports based on current service type
    const airportList = formData.serType === 1 
      ? airportsByServiceType.domestic 
      : airportsByServiceType.international;

    const filtered = filterAirports(value, airportList);
    setFilteredToAirports(filtered);
    
    // Show dropdown if there are results and search term is not empty
    setDropdowns((prevDropdowns) => ({ 
      ...prevDropdowns, 
      to: value.trim().length > 0 && filtered.length > 0 
    }));
  };

  // ✅ Update filtered airports when service type changes
  useEffect(() => {
    if (airports.length === 0) return;

    const airportList = formData.serType === 1 
      ? airportsByServiceType.domestic 
      : airportsByServiceType.international;

    // Re-filter current searches when service type changes
    const filteredFrom = filterAirports(formData.from, airportList);
    const filteredTo = filterAirports(formData.to, airportList);
    
    setFilteredFromAirports(filteredFrom);
    setFilteredToAirports(filteredTo);
    
    // Update dropdown visibility
    setDropdowns(prev => ({
      ...prev,
      from: formData.from.trim().length > 0 && filteredFrom.length > 0,
      to: formData.to.trim().length > 0 && filteredTo.length > 0
    }));
  }, [formData.serType, airportsByServiceType]);

  // Load locations on component mount
  useEffect(() => {
    fetchLocations();
  }, []);

  useEffect(() => {
    dispatch(checkUserLogin());
  }, [dispatch]);

  // Check if stored date/time has been reached and show update modal
  useEffect(() => {
    const checkUpdateDate = () => {
      const storedDate = localStorage.getItem("flightSearchUpdateDate");
      if (storedDate) {
        const updateDate = new Date(storedDate);
        const now = new Date();

        if (now >= updateDate) {
          setShowUpdateModal(true);
        }
      }
    };

    checkUpdateDate();
    const interval = setInterval(checkUpdateDate, 60000);
    return () => clearInterval(interval);
  }, []);

  // Log debug info in development
  useEffect(() => {
    if (
      typeof import.meta !== "undefined" &&
      import.meta.env?.MODE === "development" &&
      debugInfo
    ) {
      console.debug("Flight debug:", debugInfo);
    }
  }, [debugInfo]);

  // Root refs for all dropdowns
  const travellersRef = useRef(null);
  const fromRef = useRef(null);
  const toRef = useRef(null);
  const serviceRef = useRef(null);
  const fareRef = useRef(null);

  // Dropdown/outside click logic for all dropdowns
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        dropdowns.travellers &&
        travellersRef.current &&
        !travellersRef.current.contains(event.target)
      ) {
        setDropdowns((prev) => ({ ...prev, travellers: false }));
      }
      if (
        dropdowns.from &&
        fromRef.current &&
        !fromRef.current.contains(event.target)
      ) {
        setDropdowns((prev) => ({ ...prev, from: false }));
      }
      if (
        dropdowns.to &&
        toRef.current &&
        !toRef.current.contains(event.target)
      ) {
        setDropdowns((prev) => ({ ...prev, to: false }));
      }
      if (
        dropdowns.service &&
        serviceRef.current &&
        !serviceRef.current.contains(event.target)
      ) {
        setDropdowns((prev) => ({ ...prev, service: false }));
      }
      if (
        dropdowns.fare &&
        fareRef.current &&
        !fareRef.current.contains(event.target)
      ) {
        setDropdowns((prev) => ({ ...prev, fare: false }));
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [dropdowns]);

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const fetchLocations = async () => {
    try {
      setIsLoadingLocations(true);
    } catch (error) {
      console.error("Error fetching locations:", error);
      setError("Failed to load locations");
    } finally {
      setIsLoadingLocations(false);
    }
  };

  // Optimized searchFlights function with token handling
  const searchFlights = async (searchData) => {
    try {
      setDebugInfo(`Search request: ${JSON.stringify(searchData)}`);

      const response = await fetch(`${API_BASE}/api/postSearchFlight`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include", // This will automatically include the flightToken cookie if it exists
        body: JSON.stringify({
          ...searchData,
        }),
      });

      setDebugInfo(`Search response status: ${response.status}`);

      if (!response.ok) {
        const errorText = await response.text();
        setDebugInfo(`Search HTTP Error: ${response.status} - ${errorText}`);

        if (response.status === 401) {
          setDebugInfo("Token invalid or expired");
          throw new Error("Authorization failed - token expired or invalid");
        }

        throw new Error(`Search failed with status: ${response.status}`);
      }

      const data = await response.json();

      // Check for external API authorization errors
      if (data.code === "error" && data.error_msg?.includes("Authorization")) {
        setDebugInfo("Flight token expired in API response");
        throw new Error("Authorization failed - token expired");
      }

      setStatusDatas(data.data?.Status?.refID);
      setDebugInfo(`Search results: ${data.count || 0} flights found`);

      if (data.success) {
        return data.data;
      }

      if (data.error_msg) {
        throw new Error(data.error_msg);
      }

      throw new Error(data.message || "Search failed");
    } catch (error) {
      console.error("Error searching flights:", error);
      setDebugInfo(`Search error: ${error.message}`);
      throw error;
    }
  };

  // Price Verification API
  const verifyFlightPrice = async (flightId, refId) => {
    try {
      setIsLoadingPrices(true);

      const response = await fetch(`${API_BASE}/api/postPriceVerify`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          flightID: flightId,
          refID: refId,
        }),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.message || "Price verification failed");
      }

      let priceData = [];

      if (data.data && data.data.result) {
        const result = data.data.result;
        const fareOptions = [];

        if (result.Fare && result.Fare.total) {
          fareOptions.push({
            fareName: "Standard Fare",
            price: result.Fare.total.total,
            base: result.Fare.total.base,
            tax: result.Fare.total.tax,
            baggage: {
              cabin: result.Flights?.bagCbin || "7 Kgs Cabin Baggage",
              checkin: result.Flights?.bagCkin || "20 Kgs Check-in Baggage",
            },
            cancellationFee: "4,275",
            dateChangeFee: "2,999",
            seats: "chargeable",
            meals: "not available",
            refundable:
              result.Flights?.refundable === "P"
                ? "Partially Refundable"
                : "Non-Refundable",
          });
        }

        if (result.ssrInfo && result.ssrInfo.Onward) {
          const ssr = result.ssrInfo.Onward;

          if (ssr.Bagg && Array.isArray(ssr.Bagg)) {
            ssr.Bagg.forEach((bag, index) => {
              fareOptions.push({
                fareName: `Premium Fare ${index + 1}`,
                price:
                  parseInt(result.Fare.total.total) + parseInt(bag.baggAmt),
                base: result.Fare.total.base,
                tax: result.Fare.total.tax,
                baggage: {
                  cabin: result.Flights?.bagCbin || "7 Kgs Cabin Baggage",
                  checkin: `${
                    parseInt(result.Flights?.bagCkin?.split(" ")[0] || 20) +
                    parseInt(bag.baggAmt) / 1000
                  } Kgs Check-in Baggage`,
                },
                cancellationFee: "4,275",
                dateChangeFee: "2,999",
                seats: "chargeable",
                meals: "not available",
                refundable:
                  result.Flights?.refundable === "P"
                    ? "Partially Refundable"
                    : "Non-Refundable",
                ssrInfo: {
                  baggage: bag,
                },
              });
            });
          }

          if (ssr.Meal && Array.isArray(ssr.Meal)) {
            ssr.Meal.forEach((meal, index) => {
              fareOptions.push({
                fareName: `Meal Option ${index + 1}`,
                price:
                  parseInt(result.Fare.total.total) + parseInt(meal.mealAmt),
                base: result.Fare.total.base,
                tax: result.Fare.total.tax,
                baggage: {
                  cabin: result.Flights?.bagCbin || "7 Kgs Cabin Baggage",
                  checkin: result.Flights?.bagCkin || "20 Kgs Check-in Baggage",
                },
                cancellationFee: "4,275",
                dateChangeFee: "2,999",
                seats: "chargeable",
                meals: "available",
                refundable:
                  result.Flights?.refundable === "P"
                    ? "Partially Refundable"
                    : "Non-Refundable",
                ssrInfo: {
                  meal: meal,
                },
              });
            });
          }
        }

        priceData = fareOptions;
      }

      setPriceOptions(priceData);
      return priceData;
    } catch (error) {
      console.error("Price verification error:", error);
      setError(error.message);
      setPriceOptions([]);
      throw error;
    } finally {
      setIsLoadingPrices(false);
    }
  };

  // Seat Selection API
  const selectSeats = async (flightId, refId) => {
    try {
      setIsLoadingSsr(true);
      const response = await fetch(`${API_BASE}/api/selectSeats`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          flightID: flightId,
          refID: refId,
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.message || "Seat selection failed");
      }

      setSsrOptions(data.data || {});
      return data.data;
    } catch (error) {
      console.error("Seat selection error:", error);
      setError(error.message);
      throw error;
    } finally {
      setIsLoadingSsr(false);
    }
  };

  void selectSeats;

  // Booking with SSR API
  const bookFlightWithSSR = async (flightId, refId, clientId, bookingData) => {
    try {
      setIsBooking(true);
      setBookingError(null);
      setBookingResult(null);

      const response = await fetch(`${API_BASE}/api/bookFlightSSR`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          flightID: flightId,
          refID: statusDatas,
          clientID: clientId,
          selectedSeats: selectedSeats,
          ...bookingData,
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.message || "Booking with SSR failed");
      }

      const calculatedTotal = selectedFlightForPrice?.Fare?.total?.total
        ? Number(selectedFlightForPrice.Fare.total.total) + 300
        : data.data?.totalAmount || 0;

      const bookingId =
        data.data?.Status?.refID ||
        data.data?.Status?.bookingReference ||
        data.data?.bookingReference ||
        data.data?.refID ||
        statusDatas ||
        "N/A";

      const emailResult = await sendBookingConfirmationEmail({
        flightInfo: selectedFlightForPrice,
        passengerDetails: bookingData.passenger,
        contactInfo: { mobile: bookingData.mobile, email: bookingData.email },
        selectedSeats: selectedSeats,
        totalAmount: calculatedTotal,
        bookingReference: bookingId,
      });

      setBookingResult(data.data);
      setBookingSuccessData({
        ...data.data,
        bookingReference: bookingId,
        totalAmount: calculatedTotal,
        userEmail: bookingData.email,
        emailSent: emailResult.success,
        emailMessage: emailResult.message,
      });
      setShowBookingSuccess(true);
      return data.data;
    } catch (error) {
      setBookingError(error.message);
      throw error;
    } finally {
      setIsBooking(false);
    }
  };

  // Regular Booking API (without SSR)
  const bookSelectedFlight = async (flight, passenger, searchPayload) => {
    try {
      setIsBooking(true);
      setBookingError(null);
      setBookingResult(null);

      const clientId = generateClientID();
      const passengerData = generatePassengerDetails();

      const reqBody = {
        ...searchPayload,
        selected: flight,
        refID: statusDatas,
        clientID: clientId,
        selectedSeats: selectedSeats,
        passenger: passengerData,
        mobile: contactInfo.mobile || "9876543210",
        email: contactInfo.email || "werthjkyu@gmail.com",
        flightID: flight?.Flights?.Onward[0]?.flightID || 93580,
        serType: formData.serType,
        tripType: tripType,
      };

      const response = await fetch(`${API_BASE}/api/checkAuth`, {
        credentials: "include",
      });
      const dataAuth = await response.json();

      if (!dataAuth?.success) {
        setShowLoginModal(true);
        return;
      }

      const res = await fetch(`${API_BASE}/api/bookFlight`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ ...reqBody }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.message || "Booking failed");
      }

      const calculatedTotal = flight?.Fare?.total?.total
        ? Number(flight.Fare.total.total) + 300
        : data.data?.totalAmount || 0;

      const bookingId =
        data.data?.Status?.refID ||
        data.data?.Status?.bookingReference ||
        data.data?.bookingReference ||
        data.data?.refID ||
        statusDatas ||
        "N/A";

      const emailResult = await sendBookingConfirmationEmail({
        flightInfo: flight,
        passengerDetails: passengerData,
        contactInfo: { mobile: contactInfo.mobile, email: contactInfo.email },
        selectedSeats: selectedSeats,
        totalAmount: calculatedTotal,
        bookingReference: bookingId,
      });

      setBookingResult(data.data);
      setBookingSuccessData({
        ...data.data,
        bookingReference: bookingId,
        totalAmount: calculatedTotal,
        userEmail: contactInfo.email,
        emailSent: emailResult.success,
        emailMessage: emailResult.message,
      });
      setShowBookingSuccess(true);
      return data.data;
    } catch (e) {
      setBookingError(e.message);
      throw e;
    } finally {
      setIsBooking(false);
    }
  };

  // Optimized handleSearch function with token optimization
  const handleSearch = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setSearchResults([]);
    setShowResults(false);
    setDebugInfo("Starting search process...");

    try {
      if (!formData.from || !formData.to || !formData.departure) {
        throw new Error(
          "Please fill in all required fields (From, To, and Departure Date)"
        );
      }

      if (tripType == 1 && !formData.returnDate) {
        throw new Error("Please select a Return Date for Round Trip");
      }

      const totalNonInfant = (formData.adults || 0) + (formData.children || 0);
      if (formData.adults < 1 || formData.adults > 9) {
        throw new Error("Adults must be between 1 and 9");
      }
      if (totalNonInfant > 9) {
        throw new Error("Total of Adults + Children cannot exceed 9");
      }
      if (formData.infants > Math.min(4, formData.adults)) {
        throw new Error("Infants cannot be more than Adults and maximum 4");
      }

      const extractCodeFromDisplay = (displayValue) => {
        if (!displayValue) return null;
        const match = displayValue.match(/\(([A-Z]{3})\)/);
        return match ? match[1] : null;
      };

      const fromLocation = airports.find((airport) => {
        const displayFormats = [
          `${airport.name} (${airport.code})`,
          `${airport.name}, ${airport.country} (${airport.code})`,
          `${airport.city} (${airport.code})`,
          `${airport.city}, ${airport.country} (${airport.code})`,
        ];

        if (displayFormats.some((format) => format === formData.from)) {
          return true;
        }

        if (formData.from === airport.code) {
          return true;
        }

        const extractedCode = extractCodeFromDisplay(formData.from);
        if (extractedCode && extractedCode === airport.code) {
          return true;
        }

        return false;
      });

      const toLocation = airports.find((airport) => {
        const displayFormats = [
          `${airport.name} (${airport.code})`,
          `${airport.name}, ${airport.country} (${airport.code})`,
          `${airport.city} (${airport.code})`,
          `${airport.city}, ${airport.country} (${airport.code})`,
        ];

        if (displayFormats.some((format) => format === formData.to)) {
          return true;
        }

        if (formData.to === airport.code) {
          return true;
        }

        const extractedCode = extractCodeFromDisplay(formData.to);
        if (extractedCode && extractedCode === airport.code) {
          return true;
        }

        return false;
      });

      if (!fromLocation || !toLocation) {
        throw new Error(
          "Please select valid departure and arrival locations from the dropdown"
        );
      }

      const formatDate = (iso) => (iso ? iso.replaceAll("-", "") : "");
      const searchData = {
        tripType: tripType,
        serType: formData.serType,
        depCity: fromLocation.code,
        arrCity: toLocation.code,
        onDate: formatDate(formData.departure),
        reDate: tripType === 1 ? formatDate(formData.returnDate) : "",
        adt: formData.adults,
        chd: formData.children,
        inf: formData.infants,
        cabin: formData.cabin,
        fareType: formData.fareType,
      };

      setDebugInfo(`Sending search request: ${JSON.stringify(searchData)}`);
      setLastSearchPayload(searchData);

      // Step 1: Check if we have a valid flightToken in cookies
      setDebugInfo("Checking for existing flight token...");
      
      try {
        // First, try to search flights directly (assuming token exists and is valid)
        const results = await searchFlights(searchData);
        
        if (results && results.results) {
          setSearchResults(results.results);
          setCurrentPage(1);
          setStatusRefdId(results?.Status?.refID || "");
          setShowResults(true);
          setDebugInfo(
            `Search completed: ${results.results.length} flights found`
          );
          storeNextDayDate();
        } else {
          throw new Error("No flight results received from server");
        }
      } catch (searchError) {
        // If search fails with authorization error, get a new token and retry
        if (searchError.message.includes("Authorization") || 
            searchError.message.includes("401") ||
            searchError.message.includes("token") ||
            searchError.message.includes("expired")) {
          
          setDebugInfo("Token expired or invalid, fetching new token...");
          
          try {
            // Get a new token
            const tokenResponse = await fetch(`${API_BASE}/api/getToken`, {
              credentials: "include",
            });
            const tokenData = await tokenResponse.json();

            if (!tokenData?.success) {
              throw new Error("Failed to fetch flight token. Please try again.");
            }

            setDebugInfo("New token acquired, retrying search...");
            
            // Retry the search with the new token
            const retryResults = await searchFlights(searchData);
            
            if (retryResults && retryResults.results) {
              setSearchResults(retryResults.results);
              setCurrentPage(1);
              setStatusRefdId(retryResults?.Status?.refID || "");
              setShowResults(true);
              setDebugInfo(
                `Search completed after token refresh: ${retryResults.results.length} flights found`
              );
              storeNextDayDate();
            } else {
              throw new Error("No flight results received after token refresh");
            }
          } catch (tokenError) {
            console.error("Token refresh error:", tokenError);
            throw new Error(
              "Unable to authenticate with flight service. Please refresh the page and try again."
            );
          }
        } else {
          // Re-throw other errors
          throw searchError;
        }
      }
    } catch (error) {
      console.error("Search error:", error);
      setError(error.message);
      setDebugInfo(`Final error: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleDropdown = (dropdown) => {
    setDropdowns((prev) => {
      const wasOpen = !!prev[dropdown];
      const closedAll = Object.keys(prev).reduce((acc, key) => {
        acc[key] = false;
        return acc;
      }, {});
      return {
        ...closedAll,
        [dropdown]: !wasOpen,
      };
    });
  };

  const selectOption = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
    setDropdowns((prev) => ({
      ...prev,
      [field]: false,
    }));
  };

  const swapLocations = () => {
    setFormData((prev) => ({
      ...prev,
      from: prev.to,
      to: prev.from,
    }));
  };

  const toggleFlightDetails = (flightIndex) => {
    setExpandedFlights((prev) => ({
      ...prev,
      [flightIndex]: !prev[flightIndex],
    }));
  };

  // Generate unique clientID
  const { authdata } = useSelector((state) => state.auth);
  const generateClientID = () => {
    return authdata?.token?._id;
  };

  // Derived auth state
  const isLoggedIn = Boolean(authdata && authdata.token);

  // Initialize passenger form data
  const initializePassengerData = useCallback(() => {
    const totalpassenger =
      formData.adults + formData.children + formData.infants;
    const initialData = [];

    for (let i = 0; i < totalpassenger; i++) {
      initialData[i] = {
        title: "Mr",
        fName: "",
        lName: "",
        gender: "M",
        dob: "",
        ppNo: "",
        ppIss: "",
        ppExp: "",
        ppNat: "IN",
      };
    }

    setFormPassengerData(initialData);
  }, [formData.adults, formData.children, formData.infants]);

  // Initialize passenger data when form opens
  useEffect(() => {
    if (showPassengerForm) {
      initializePassengerData();
    }
  }, [showPassengerForm, initializePassengerData]);

  // Handle passenger form data changes
  const handlePassengerDataChange = (passengerIndex, field, value) => {
    setFormPassengerData((prev) => {
      const newData = [...prev];
      newData[passengerIndex] = {
        ...newData[passengerIndex],
        [field]: value,
      };
      return newData;
    });

    setValue(`passengers.${passengerIndex}.${field}`, value, {
      shouldValidate: false,
      shouldDirty: true,
    });
  };

  // Convert date from YYYY-MM-DD to DD-MM-YYYY format
  const formatDateForAPI = (dateString) => {
    if (!dateString) return "01-01-1990";
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  };

  // Generate passenger details from form data
  const generatePassengerDetails = () => {
    const totalpassenger =
      formData.adults + formData.children + formData.infants;
    const passenger = [];

    if (totalpassenger === 0) {
      const defaultPassenger = {
        title: "Mr",
        fName: "Test",
        lName: "User",
        pType: "A",
        gender: "M",
        dob: "01-01-1990",
        mobile: contactInfo.mobile || "",
        email: contactInfo.email || "",
      };

      if (formData.serType === 2) {
        defaultPassenger.ppNo = "";
        defaultPassenger.ppIss = "";
        defaultPassenger.ppExp = "";
        defaultPassenger.ppNat = "IN";
      }

      return [defaultPassenger];
    }

    for (let i = 0; i < totalpassenger; i++) {
      const passengerData = formPassengerData[i] || [];
      const passengerType =
        i < formData.adults
          ? "A"
          : i < formData.adults + formData.children
          ? "C"
          : "I";

      const passengerObj = {
        title: passengerData.title || "Mr",
        fName: passengerData.fName || "Test",
        lName: passengerData.lName || "User",
        pType: passengerType,
        gender: passengerData.gender || "M",
        dob: formatDateForAPI(passengerData.dob),
      };

      if (formData.serType === 2) {
        passengerObj.ppNo = passengerData.ppNo || "";
        passengerObj.ppIss = formatDateForAPI(passengerData.ppIss);
        passengerObj.ppExp = formatDateForAPI(passengerData.ppExp);
        passengerObj.ppNat = passengerData.ppNat || "IN";
      }

      passenger.push(passengerObj);
    }

    return passenger;
  };

  // Generate simplified passenger details for seat selection
  const generateSeatPassengerDetails = () => {
    const totalpassenger =
      formData.adults + formData.children + formData.infants;
    const passenger = [];

    if (totalpassenger === 0) {
      return [
        {
          title: "Mr",
          fName: "Test",
          lName: "User",
          pType: "A",
        },
      ];
    }

    for (let i = 0; i < totalpassenger; i++) {
      const passengerData = formPassengerData[i] || [];
      const passengerType =
        i < formData.adults
          ? "A"
          : i < formData.adults + formData.children
          ? "C"
          : "I";

      passenger.push({
        title: passengerData.title || "Mr",
        fName: passengerData.firstName || "Test",
        lName: passengerData.lastName || "User",
        pType: passengerType,
      });
    }

    return passenger;
  };

  // Fetch available seats
  const fetchSeats = async (flightId, refId) => {
    try {
      setIsLoadingSeats(true);
      const passengerDetails = generateSeatPassengerDetails();

      const response = await fetch(`${API_BASE}/api/seats`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          flightID: flightId,
          refID: refId,
          passenger: passengerDetails,
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.message || "Seat fetching failed");
      }

      const seatMap = data.data?.FlightSeat?.Onward?.[0]?.SeatMap || [];
      setAvailableSeats(seatMap);
      return seatMap;
    } catch (error) {
      console.error("Error fetching seats:", error);
      setAvailableSeats([]);
      throw error;
    } finally {
      setIsLoadingSeats(false);
    }
  };

  // Send booking confirmation email
  const sendBookingConfirmationEmail = async (bookingData) => {
    try {
      const emailData = {
        to: bookingData.contactInfo?.email || "itzzzamaan001@gmail.com",
        subject: "Flight Booking Confirmation",
        bookingDetails: {
          flightInfo: bookingData.flightInfo || {},
          passengerDetails: bookingData.passengerDetails || [],
          contactInfo: bookingData.contactInfo || {},
          selectedSeats: bookingData.selectedSeats || {},
          totalAmount: bookingData.totalAmount || 0,
          bookingReference: bookingData.bookingReference || "N/A",
          bookingDate: new Date().toLocaleString(),
        },
      };

      await new Promise((resolve) => setTimeout(resolve, 1000));

      return {
        success: true,
        message: "Booking confirmation email sent successfully",
      };
    } catch (error) {
      console.error("Error sending booking confirmation email:", error);
      return { success: false, message: "Failed to send confirmation email" };
    }
  };

  // Set minimum date for departure as today
  const getTodayDate = () => {
    return new Date().toISOString().split("T")[0];
  };

  // Set minimum return date as departure date
  const getMinReturnDate = () => {
    return formData.departure || getTodayDate();
  };

  // Helpers to render API date/time and durations from API format
  const formatApiDateTime = (str) => {
    if (!str || str.length < 12) return "N/A";
    const y = Number(str.slice(0, 4));
    const m = Number(str.slice(4, 6)) - 1;
    const d = Number(str.slice(6, 8));
    const hh = Number(str.slice(8, 10));
    const mm = Number(str.slice(10, 12));
    const dt = new Date(y, m, d, hh, mm);
    return dt.toLocaleString(undefined, {
      year: "numeric",
      month: "short",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const minutesToHm = (minsStr) => {
    const mins = Number(minsStr || 0);
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return `${h}h ${m}m`;
  };

  const getSegments = (leg) => {
    if (!leg) return [];
    const vals = Array.isArray(leg) ? leg : Object.values(leg);
    return vals.filter((s) => s && s.flightNo);
  };

  const getStopsText = (leg) => {
    const segs = getSegments(leg);
    const stops = Math.max(0, segs.length - 1);
    if (stops === 0) return "Non-stop";
    const vias = segs
      .slice(0, -1)
      .map((s) => s.arrCode)
      .join(", ");
    return `${stops} Stop${stops > 1 ? "s" : ""}${vias ? ` via ${vias}` : ""}`;
  };

  const getTotalDurationMinutes = (leg) => {
    if (!leg) return 0;
    if (leg.durTotal) return Number(leg.durTotal);
    const segs = getSegments(leg);
    return segs.reduce((sum, s) => sum + Number(s.duration || 0), 0);
  };

  const handleAuthCheck = async (fare) => {
    const response = await fetch(`${API_BASE}/api/checkAuth`, {
      credentials: "include",
    });
    const dataAuth = await response.json();
    if (!dataAuth?.success) {
      setShowLoginModal(true);
      return;
    }

    setSelectedFare(fare);
    setShowPassengerForm(true);
  };

  // ✅ DOB validation helper
  const handleDobChange = (value, index, type) => {
    const dobDate = new Date(value);

    if (type === "infant") {
      if (dobDate < sixtyDaysAgo || dobDate > today) {
        alert("Infant DOB must be within the last 60 days");
        return;
      }
    }
    if (type === "child") {
      if (dobDate < twelveYearsAgo || dobDate > today) {
        alert("Child DOB must be within the last 12 years");
        return;
      }
    }

    setFormPassengerData((prevData) => {
      const updatedData = [...prevData];
      updatedData[index] = {
        ...updatedData[index],
        dob: value,
      };
      return updatedData;
    });

    setValue(`passengers.${index}.dob`, value, {
      shouldValidate: false,
      shouldDirty: true,
    });
  };

  // ✅ Keep your existing booking logic
  const handleBookFlight = handleSubmit(async () => {
    if (isBooking) return;
    try {
      const clientId = generateClientID();
      const flightId =
        selectedFlightForPrice.flightID ||
        selectedFlightForPrice.flightId ||
        75318;
      const refId = selectedFlightForPrice.refID || "API25101721283BBOJ073611";

      const generatedpassenger = generatePassengerDetails();

      const bookingData = {
        passenger: generatedpassenger,
        refID: statusDatas,
        clientID: clientId,
        flightID: flightId,
        mobile: contactInfo.mobile || "9876543210",
        email: contactInfo.email || "werthjkyu@gmail.com",
        status: null,
        selectedSeats: selectedSeats,
      };

      if (selectedSsr.type === "with") {
        await bookFlightWithSSR(flightId, refId, clientId, bookingData);
      } else {
        await bookSelectedFlight(
          selectedFlightForPrice,
          passengerDetails,
          lastSearchPayload || {}
        );
      }

      setShowPassengerForm(false);
      setShowPriceModal(false);
    } catch (error) {
      console.error("Booking error", error);
    }
  });

  const handlePay = async (onSuccess) => {
    try {
      if (!selectedFlightForPrice) {
        alert("Please select a flight and fare option first.");
        setIsPaying(false);
        return;
      }
      if (!amount) {
        alert("Please set the amount first.");
        setIsPaying(false);
        return;
      }

      const { data } = await axios.post(
        `${API_BASE}/create-order`,
        {
          amount: amount,
        },
        { withCredentials: true }
      );

      if (!data?.order) {
        alert("Failed to create order");
        setIsPaying(false);
        return;
      }

      const options = {
        key: import.meta.env.VITE_KEYID,
        amount: data.order.amount,
        currency: "INR",
        name: "FTD Travel",
        description: "Flight Booking Payment",
        order_id: data.order.id,
        handler: function (response) {
          alert("Payment successful!");
          if (typeof onSuccess === "function") {
            onSuccess(response);
          }
        },
        prefill: {
          name: "Mohammad Ayan",
          email: "ayan@example.com",
          contact: "9999999999",
        },
        notes: {
          address: "FTD Travel Office",
        },
        theme: {
          color: "#3399cc",
        },
      };

      if (!window.Razorpay) {
        alert("Payment system not available. Please try again later.");
        setIsPaying(false);
        return;
      }

      const razor = new window.Razorpay(options);
      razor.open();

      if (razor && typeof razor.on === "function") {
        try {
          razor.on("modal.closed", function () {
            setIsPaying(false);
          });
        } catch (_) {}
      }

      razor.on("payment.failed", function (response) {
        console.error("❌ Payment Failed:", response.error);
        alert("Payment failed. Please try again.");
        setIsPaying(false);
      });
    } catch (err) {
      console.error("Payment Error:", err);
      setIsPaying(false);
    }
  };

  const initiateBooking = () => {
    if (isPaying) return;
    setIsPaying(true);
    handlePay(async (paymentResponse) => {
      await handleBookFlight();
      setIsPaying(false);
      setIsOpen(false);
    });
  };

  // Store next day date in localStorage when flight search is successful
  const storeNextDayDate = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);
    localStorage.setItem("flightSearchUpdateDate", tomorrow.toISOString());
  };

  // Clear all localStorage and cookies, then store next day date
  const handleUpdateStorage = () => {
    localStorage.clear();
    document.cookie.split(";").forEach((c) => {
      document.cookie = c
        .replace(/^ +/, "")
        .replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/");
    });
    storeNextDayDate();
    setShowUpdateModal(false);
    toast.success("Storage updated successfully!", {
      position: "top-center",
      autoClose: 3000,
    });
  };

  // Handle feedback submission
  const handleFeedbackSubmit = async () => {
    if (rating === 0) {
      toast.error("Please provide a rating", {
        position: "top-center",
        autoClose: 3000,
      });
      return;
    }

    setIsSubmittingFeedback(true);
    try {
      const response = await axios.post(
        `${API_BASE}/api/review/create`,
        {
          rating: String(rating),
          description: feedbackText || "",
        },
        { withCredentials: true }
      );

      if (response.data.success) {
        toast.success(response.data.message || "Thank you for your feedback!", {
          position: "top-center",
          autoClose: 3000,
        });
        setShowFeedbackModal(false);
        setShowPassengerForm(false);
        setShowPriceModal(false);
        setBookingSuccessData(null);
        setRating(0);
        setFeedbackText("");
      } else {
        toast.error(
          response.data.message ||
            "Failed to submit feedback. Please try again.",
          {
            position: "top-center",
            autoClose: 3000,
          }
        );
      }
    } catch (error) {
      console.error("Feedback submission error:", error);
      if (error.response?.status === 401) {
        toast.error("Please login to submit feedback", {
          position: "top-center",
          autoClose: 3000,
        });
      } else if (error.response?.data?.message) {
        toast.error(error.response.data.message, {
          position: "top-center",
          autoClose: 3000,
        });
      } else {
        toast.error("Failed to submit feedback. Please try again.", {
          position: "top-center",
          autoClose: 3000,
        });
      }
    } finally {
      setIsSubmittingFeedback(false);
    }
  };

  // Fetch airports on component mount
  useEffect(() => {
    const fetchAirports = async () => {
      try {
        const response = await fetch(`${API_BASE}/api/airport`, {
          credentials: "include",
        });
        const data = await response.json();
        if (data.success && data.data) {
          const mappedAirports = data.data.map((airport) => ({
            code: airport.airportcode || airport.code,
            name: airport.airportname || airport.name,
            city: airport.airportcity || airport.city,
            country: airport.airportcountry || airport.country,
            airport: airport.airportname || airport.name,
          }));
          setAirports(mappedAirports);
          setFilteredFromAirports(mappedAirports);
          setFilteredToAirports(mappedAirports);
        }
      } catch (error) {
        console.error("Error fetching airports:", error);
      }
    };
    fetchAirports();
  }, []);

  return (
    <div>
      <div
        className="min-h-screen md:h-[80vh] pb-8 relative overflow-hidden"
        style={{
          backgroundImage: `url(${flighthome})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
        }}
      >
        <div className="absolute inset-0 bg-blue-900/20 bg-opacity-20"></div>

        {/* Background Airplane */}
        <div className="absolute inset-0 overflow-hidden">
          <motion.div
            className="absolute md:top-13 top-11 right-10 w-96 h-96 opacity-80"
            initial={{ x: 100, y: -50, rotate: 15 }}
            animate={{ x: 0, y: 0, rotate: 0 }}
            transition={{ duration: 2, ease: "easeOut" }}
          >
            <FaPlane className="text-9xl text-black" />
          </motion.div>
        </div>

        {/* Main Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 md:py-14 pt-8">
          <div className="flex flex-col items-center">
            {/* Main Heading */}
            <motion.h1
              className="text-[42px] md:text-6xl font-bold text-white text-center md:mb-13 mb-15"
              initial={{ opacity: 0, y: -50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1 }}
            >
              Ready to take off?
            </motion.h1>

            {/* Search Form */}
            <SearchForm
              formData={formData}
              setFormData={setFormData}
              tripType={tripType}
              setTripType={setTripType}
              airports={airports}
              airportsByServiceType={airportsByServiceType}
              filteredFromAirports={filteredFromAirports}
              setFilteredFromAirports={setFilteredFromAirports}
              filteredToAirports={filteredToAirports}
              setFilteredToAirports={setFilteredToAirports}
              dropdowns={dropdowns}
              setDropdowns={setDropdowns}
              isLoading={isLoading}
              handleSearch={handleSearch}
              handleFromInputChange={handleFromInputChange}
              handleToInputChange={handleToInputChange}
              filterAirports={filterAirports}
              toggleDropdown={toggleDropdown}
              selectOption={selectOption}
              swapLocations={swapLocations}
              handleInputChange={handleInputChange}
              getTodayDate={getTodayDate}
              getMinReturnDate={getMinReturnDate}
              travellersRef={travellersRef}
              fromRef={fromRef}
              toRef={toRef}
              serviceRef={serviceRef}
              fareRef={fareRef}
              isLoadingLocations={isLoadingLocations}
            />
          </div>
        </div>
      </div>

      {/* Error Display */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mx-4 mt-4 max-w-5xl mx-auto">
          <div className="flex items-center">
            <FaExclamationTriangle className="text-red-500 mr-3 flex-shrink-0" />
            <div className="flex-1">
              <p className="text-red-700 font-semibold">Search Error</p>
              <p className="text-red-600 text-sm mt-1">{error}</p>
            </div>
            <button
              onClick={() => setError(null)}
              className="ml-4 text-red-500 hover:text-red-700 flex-shrink-0"
            >
              <FaTimes />
            </button>
          </div>
        </div>
      )}

      {/* Flight Results */}
      <FlightResults
        showResults={showResults}
        setShowResults={setShowResults}
        searchResults={searchResults}
        pagedResults={pagedResults}
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
        totalPages={totalPages}
        pageSize={pageSize}
        tripType={tripType}
        expandedFlights={expandedFlights}
        toggleFlightDetails={toggleFlightDetails}
        setSelectedFlightForPrice={setSelectedFlightForPrice}
        setShowPriceModal={setShowPriceModal}
        verifyFlightPrice={verifyFlightPrice}
        statusRefdId={statusRefdId}
        formatApiDateTime={formatApiDateTime}
        minutesToHm={minutesToHm}
        getSegments={getSegments}
        getStopsText={getStopsText}
        getTotalDurationMinutes={getTotalDurationMinutes}
      />

      {/* Price Modal */}
      <PriceModal
        showPriceModal={showPriceModal}
        setShowPriceModal={setShowPriceModal}
        selectedFlightForPrice={selectedFlightForPrice}
        isLoadingPrices={isLoadingPrices}
        priceOptions={priceOptions}
        handleAuthCheck={handleAuthCheck}
      />

      {/* Passenger Form */}
      <PassengerForm
        showPassengerForm={showPassengerForm}
        setShowPassengerForm={setShowPassengerForm}
        selectedFare={selectedFare}
        formData={formData}
        formPassengerData={formPassengerData}
        setFormPassengerData={setFormPassengerData}
        contactInfo={contactInfo}
        setContactInfo={setContactInfo}
        showSeatSelection={showSeatSelection}
        setShowSeatSelection={setShowSeatSelection}
        availableSeats={availableSeats}
        setAvailableSeats={setAvailableSeats}
        selectedSeats={selectedSeats}
        setSelectedSeats={setSelectedSeats}
        isLoadingSeats={isLoadingSeats}
        selectedSsr={selectedSsr}
        setSelectedSsr={setSelectedSsr}
        isBooking={isBooking}
        handleSubmit={handleSubmit}
        register={register}
        errors={errors}
        handlePassengerDataChange={handlePassengerDataChange}
        handleDobChange={handleDobChange}
        fetchSeats={fetchSeats}
        selectedFlightForPrice={selectedFlightForPrice}
        statusRefdId={statusRefdId}
        setIsOpen={setIsOpen}
        handleBookFlight={handleBookFlight}
      />

      <PaymentModal
        isOpen={isOpen}
        onClose={() => {
          setIsOpen(false), setIsPaying(false);
        }}
        onConfirm={initiateBooking}
        fareData={selectedFlightForPrice}
        isPaying={isPaying}
        ssrType={selectedSsr?.type}
        setAmount={setAmount}
        serType={formData.serType}
        seatTotal={Object.values(selectedSeats).reduce(
          (sum, seat) => sum + parseInt(seat?.seatAmt || 0),
          0
        )}
      />

      <LoginModal
        isOpen={showLoginModal}
        onClose={() => setShowLoginModal(false)}
        onLoginSuccess={() => {
          setShowLoginModal(false);
          if (pendingFareForAuth) {
            setSelectedFare(pendingFareForAuth);
            setShowPassengerForm(true);
            setPendingFareForAuth(null);
          }
        }}
      />

      {/* Booking Success Modal */}
      <BookingSuccessModal
        showBookingSuccess={showBookingSuccess}
        setShowBookingSuccess={setShowBookingSuccess}
        bookingSuccessData={bookingSuccessData}
        selectedFlightForPrice={selectedFlightForPrice}
        contactInfo={contactInfo}
        setShowFeedbackModal={setShowFeedbackModal}
      />

      {/* Feedback Modal */}
      <FeedbackModal
        showFeedbackModal={showFeedbackModal}
        setShowFeedbackModal={setShowFeedbackModal}
        setShowPassengerForm={setShowPassengerForm}
        setShowPriceModal={setShowPriceModal}
        setBookingSuccessData={setBookingSuccessData}
        rating={rating}
        setRating={setRating}
        feedbackText={setFeedbackText}
        setFeedbackText={setFeedbackText}
        isSubmittingFeedback={isSubmittingFeedback}
        handleFeedbackSubmit={handleFeedbackSubmit}
      />

      {/* Update Storage Modal */}
      <UpdateStorageModal
        showUpdateModal={showUpdateModal}
        setShowUpdateModal={setShowUpdateModal}
        handleUpdateStorage={handleUpdateStorage}
      />

      {/* Sections */}
      <Features />
      <SpecialOffer />
      <Price />
      <About />
      <Services />
      <Testimonials />
      <Faq />

      <ToastContainer
        position="top-center"
        autoClose={4000}
        hideProgressBar={false}
        newestOnTop={true}
        closeOnClick
        pauseOnHover
        draggable
      />
    </div>
  );
};

export default Homepage2;