const BookingSuccessModal = ({
    showBookingSuccess,
    setShowBookingSuccess,
    bookingSuccessData,
    selectedFlightForPrice,
    contactInfo,
    setShowFeedbackModal,
  }) => {
    if (!showBookingSuccess) return null;
  
    return (
      <div className="fixed inset-0 bg-black/50 bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
          <div className="p-6">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg
                  className="w-8 h-8 text-green-600"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                Booking Confirmed!
              </h2>
              <p className="text-gray-600">
                Your flight has been successfully booked.
              </p>
            </div>
  
            <div className="space-y-4 mb-6">
              <BookingDetails bookingSuccessData={bookingSuccessData} selectedFlightForPrice={selectedFlightForPrice} />
              <EmailConfirmation bookingSuccessData={bookingSuccessData} contactInfo={contactInfo} />
            </div>
  
            <div className="flex gap-3">
              <button
                onClick={() => {
                  setShowBookingSuccess(false);
                  setShowFeedbackModal(true);
                }}
                className="flex-1 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };
  
  const BookingDetails = ({ bookingSuccessData, selectedFlightForPrice }) => (
    <div className="bg-gray-50 p-4 rounded-lg">
      <h3 className="font-semibold text-gray-900 mb-2">
        Booking Details
      </h3>
      <div className="space-y-2 text-sm">
        <div className="flex justify-between">
          <span className="text-gray-600">Booking Reference:</span>
          <span className="font-medium">
            {bookingSuccessData?.Status?.refID ||
              bookingSuccessData?.Status?.bookingReference ||
              bookingSuccessData?.bookingReference ||
              bookingSuccessData?.refID ||
              "N/A"}
          </span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-600">Total Amount:</span>
          <span className="font-medium">
            ₹
            {bookingSuccessData?.totalAmount ||
              (selectedFlightForPrice?.Fare?.total?.total
                ? Number(selectedFlightForPrice.Fare.total.total) + 300
                : "N/A")}
          </span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-600">Booking Date:</span>
          <span className="font-medium">
            {new Date().toLocaleString()}
          </span>
        </div>
      </div>
    </div>
  );
  
  const EmailConfirmation = ({ bookingSuccessData, contactInfo }) => (
    <div className="bg-blue-50 p-4 rounded-lg">
      <div className="flex items-center gap-2 mb-2">
        <svg
          className="w-5 h-5 text-blue-600"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
          />
        </svg>
        <h3 className="font-semibold text-blue-900">
          Email Confirmation
        </h3>
      </div>
      <p className="text-sm text-blue-800">
        {bookingSuccessData?.emailSent
          ? `Booking confirmation details have been sent to ${
              bookingSuccessData?.userEmail ||
              contactInfo?.email ||
              "your registered email"
            }`
          : "Failed to send email confirmation. Please contact support."}
      </p>
    </div>
  );
  
  export default BookingSuccessModal;