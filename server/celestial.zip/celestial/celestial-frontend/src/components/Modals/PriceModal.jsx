import { motion } from "framer-motion";
import { FaTimes, FaSpinner, FaPlane, FaCheckCircle, FaExclamationTriangle, FaInfoCircle } from "react-icons/fa";

const PriceModal = ({
  showPriceModal,
  setShowPriceModal,
  selectedFlightForPrice,
  isLoadingPrices,
  priceOptions,
  handleAuthCheck,
}) => {
  if (!showPriceModal) return null;

  console.log("PriceModal rendered, showPriceModal:", showPriceModal);
  console.log("Selected flight:", selectedFlightForPrice);

  return (
    <div className="fixed inset-0 bg-black/60 bg-opacity-50 flex items-center justify-center z-50 p-4">
      <motion.div
        className="bg-white rounded-2xl max-w-6xl w-full max-h-[90vh] overflow-y-auto"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
      >
        <ModalHeader setShowPriceModal={setShowPriceModal} />
        <ModalContent
          isLoadingPrices={isLoadingPrices}
          priceOptions={priceOptions}
          handleAuthCheck={handleAuthCheck}
          selectedFlightForPrice={selectedFlightForPrice}
        />
      </motion.div>
    </div>
  );
};

const ModalHeader = ({ setShowPriceModal }) => (
  <div className="flex items-center justify-between p-6 border-b border-gray-200">
    <h2 className="text-2xl font-bold text-gray-900">
      Flight Details and Fare Options
    </h2>
    <button
      onClick={() => setShowPriceModal(false)}
      className="text-gray-500 hover:text-gray-700 text-2xl"
    >
      <FaTimes />
    </button>
  </div>
);

const ModalContent = ({ isLoadingPrices, priceOptions, handleAuthCheck, selectedFlightForPrice }) => (
  <div className="p-6">
    {!selectedFlightForPrice ? (
      <div className="text-center py-8">
        <FaPlane className="text-4xl text-gray-400 mx-auto mb-4" />
        <h3 className="text-xl font-semibold text-gray-600 mb-2">
          No Flight Selected
        </h3>
        <p className="text-gray-500">
          Please select a flight to view prices.
        </p>
      </div>
    ) : isLoadingPrices ? (
      <div className="text-center py-8">
        <FaSpinner className="animate-spin text-4xl text-blue-600 mx-auto mb-4" />
        <p className="text-gray-600">Loading fare options...</p>
      </div>
    ) : (
      <div className="space-y-2 grid grid-cols-1 md:grid-cols-3 gap-4">
        {Array.isArray(priceOptions) && priceOptions.length > 0 ? (
          priceOptions.map((fare, index) => (
            <FareOption
              key={index}
              fare={fare}
              index={index}
              handleAuthCheck={handleAuthCheck}
            />
          ))
        ) : (
          <NoFareOptions />
        )}
      </div>
    )}
  </div>
);

const FareOption = ({ fare, index, handleAuthCheck }) => (
  <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
    <div className="flex items-center justify-between mb-4">
      <div>
        <div className="text-2xl font-bold text-gray-900">
          ₹{fare.price || "N/A"}
        </div>
        <div className="text-sm text-gray-500">
          per adult
        </div>
      </div>
      <div className="text-right">
        <div className="font-semibold text-gray-900">
          {fare.fareName || "Fare Option"}
        </div>
        {fare.badge && (
          <div className="inline-flex items-center gap-1 bg-black text-white px-2 py-1 rounded text-xs">
            <span>★</span>
            {fare.badge}
          </div>
        )}
      </div>
    </div>

    <div className="grid grid-cols-1 gap-4 mb-4">
      <BaggageSection baggage={fare.baggage} />
      <FlexibilitySection fare={fare} />
      <SeatsMealsSection fare={fare} />
    </div>

    <div className="flex gap-3">
      <button
        onClick={() => handleAuthCheck(fare)}
        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors w-full"
      >
        BOOK NOW
      </button>
    </div>
  </div>
);

const BaggageSection = ({ baggage }) => (
  <div>
    <h4 className="font-semibold text-gray-700 mb-2">Baggage</h4>
    <div className="space-y-1">
      <div className="flex items-center gap-2 text-sm">
        <FaCheckCircle className="text-green-500" />
        <span>{baggage?.cabin || "7 Kgs Cabin Baggage"}</span>
      </div>
      <div className="flex items-center gap-2 text-sm">
        <FaCheckCircle className="text-green-500" />
        <span>{baggage?.checkin || "20 Kgs Check-in Baggage"}</span>
      </div>
    </div>
  </div>
);

const FlexibilitySection = ({ fare }) => (
  <div>
    <h4 className="font-semibold text-gray-700 mb-2">Flexibility</h4>
    <div className="space-y-1">
      <div className="flex items-center gap-2 text-sm">
        <FaExclamationTriangle className="text-orange-500" />
        <span>Cancellation fee starts at ₹{fare.cancellationFee || "4,275"}</span>
      </div>
      <div className="flex items-center gap-2 text-sm">
        <FaExclamationTriangle className="text-orange-500" />
        <span>Date Change fee starts at ₹{fare.dateChangeFee || "2,999"}</span>
      </div>
      <div className="flex items-center gap-2 text-sm">
        <FaInfoCircle className="text-blue-500" />
        <span>Refund: {fare.refundable || "Partially Refundable"}</span>
      </div>
    </div>
  </div>
);

const SeatsMealsSection = ({ fare }) => (
  <div>
    <h4 className="font-semibold text-gray-700 mb-2">Seats, Meals & More</h4>
    <div className="space-y-1">
      {fare.seats === "free" ? (
        <div className="flex items-center gap-2 text-sm">
          <FaCheckCircle className="text-green-500" />
          <span>Free Seats</span>
        </div>
      ) : (
        <div className="flex items-center gap-2 text-sm">
          <FaExclamationTriangle className="text-orange-500" />
          <span>Chargeable Seats</span>
        </div>
      )}
      {fare.meals === "available" ? (
        <div className="flex items-center gap-2 text-sm">
          <FaCheckCircle className="text-green-500" />
          <span>Meals Available</span>
        </div>
      ) : fare.meals === "free" ? (
        <div className="flex items-center gap-2 text-sm">
          <FaCheckCircle className="text-green-500" />
          <span>Complimentary Meals</span>
        </div>
      ) : (
        <div className="flex items-center gap-2 text-sm">
          <FaTimes className="text-red-500" />
          <span>Meals information not available</span>
        </div>
      )}
      {fare.ssrInfo?.baggage && (
        <div className="flex items-center gap-2 text-sm">
          <FaInfoCircle className="text-blue-500" />
          <span>Extra Baggage: {fare.ssrInfo.baggage.baggDesc}</span>
        </div>
      )}
      {fare.ssrInfo?.meal && (
        <div className="flex items-center gap-2 text-sm">
          <FaInfoCircle className="text-blue-500" />
          <span>Meal: {fare.ssrInfo.meal.mealDesc}</span>
        </div>
      )}
    </div>
  </div>
);

const NoFareOptions = () => (
  <div className="text-center py-8 col-span-3">
    <FaPlane className="text-4xl text-gray-400 mx-auto mb-4" />
    <h3 className="text-xl font-semibold text-gray-600 mb-2">
      No Fare Options Available
    </h3>
    <p className="text-gray-500">
      No fare options found for this flight. Please try again.
    </p>
  </div>
);

export default PriceModal;