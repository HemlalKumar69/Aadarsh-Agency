const ContactInfo = ({
    contactInfo,
    setContactInfo,
    register,
    errors,
    setValue,
  }) => {
    return (
      <div className="border border-gray-200 rounded-lg p-4">
        <h3 className="font-semibold mb-4">Contact Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">
              Mobile Number
            </label>
            <input
              type="tel"
              {...register("mobile")}
              value={contactInfo.mobile}
              maxLength={"10"}
              onChange={(e) => {
                let value = e.target.value.replace(/\D/g, "");
                if (value.length === 1 && !/[6-9]/.test(value)) value = "";
                if (value.length > 10) value = value.slice(0, 10);
                setContactInfo((prev) => ({
                  ...prev,
                  mobile: value,
                }));
                setValue("mobile", value, {
                  shouldValidate: false,
                  shouldDirty: true,
                });
              }}
              className="w-full px-3 py-2 border rounded-lg"
            />
            {errors.mobile && (
              <p className="text-red-500 text-xs mt-1">
                {errors.mobile.message}
              </p>
            )}
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">
              Email Address
            </label>
            <input
              type="email"
              {...register("email")}
              value={contactInfo.email}
              onChange={(e) => {
                const value = e.target.value;
                setContactInfo((prev) => ({
                  ...prev,
                  email: value,
                }));
                setValue("email", value, {
                  shouldValidate: false,
                  shouldDirty: true,
                });
              }}
              className="w-full px-3 py-2 border rounded-lg"
            />
            {errors.email && (
              <p className="text-red-500 text-xs mt-1">
                {errors.email.message}
              </p>
            )}
          </div>
        </div>
      </div>
    );
  };
  
  export default ContactInfo;