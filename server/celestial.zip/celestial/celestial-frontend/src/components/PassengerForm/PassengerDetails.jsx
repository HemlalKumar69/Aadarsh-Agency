const PassengerDetails = ({
    formData,
    formPassengerData,
    handlePassengerDataChange,
    handleDobChange,
    register,
    errors,
  }) => {
    return (
      <>
        {Array.from({
          length: formData.adults + formData.children + formData.infants,
        }).map((_, index) => {
          const type =
            index < formData.adults
              ? "adult"
              : index < formData.adults + formData.children
              ? "child"
              : "infant";
  
          return (
            <div
              key={index}
              className="border border-gray-200 rounded-lg p-4"
            >
              <h3 className="font-semibold text-gray-900 mb-4">
                Passenger {index + 1} (
                {type.charAt(0).toUpperCase() + type.slice(1)})
              </h3>
  
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Title */}
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Title
                  </label>
                  <select
                    {...register(`passengers.${index}.title`)}
                    value={formPassengerData[index]?.title || "Mr"}
                    onChange={(e) =>
                      handlePassengerDataChange(
                        index,
                        "title",
                        e.target.value
                      )
                    }
                    className="w-full px-3 py-2 border rounded-lg"
                  >
                    <option value="Mr">Mr</option>
                    <option value="Ms">Ms</option>
                    <option value="Mrs">Mrs</option>
                    <option value="Dr">Dr</option>
                  </select>
                  {errors.passengers?.[index]?.title && (
                    <p className="text-red-500 text-xs mt-1">
                      {errors.passengers[index].title.message}
                    </p>
                  )}
                </div>
  
                {/* Gender */}
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Gender
                  </label>
                  <select
                    {...register(`passengers.${index}.gender`)}
                    value={formPassengerData[index]?.gender || "M"}
                    onChange={(e) =>
                      handlePassengerDataChange(
                        index,
                        "gender",
                        e.target.value
                      )
                    }
                    className="w-full px-3 py-2 border rounded-lg"
                  >
                    <option value="M">Male</option>
                    <option value="F">Female</option>
                  </select>
                </div>
  
                {/* First Name */}
                <div>
                  <label className="block text-sm font-medium mb-1">
                    First Name
                  </label>
                  <input
                    type="text"
                    {...register(`passengers.${index}.fName`)}
                    value={formPassengerData[index]?.fName || ""}
                    onChange={(e) =>
                      handlePassengerDataChange(
                        index,
                        "fName",
                        e.target.value
                      )
                    }
                    className="w-full px-3 py-2 border rounded-lg"
                  />
                  {errors.passengers?.[index]?.fName && (
                    <p className="text-red-500 text-xs mt-1">
                      {errors.passengers[index].fName.message}
                    </p>
                  )}
                </div>
  
                {/* Last Name */}
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Last Name
                  </label>
                  <input
                    type="text"
                    {...register(`passengers.${index}.lName`)}
                    value={formPassengerData[index]?.lName || ""}
                    onChange={(e) =>
                      handlePassengerDataChange(
                        index,
                        "lName",
                        e.target.value
                      )
                    }
                    className="w-full px-3 py-2 border rounded-lg"
                  />
                  {errors.passengers?.[index]?.lName && (
                    <p className="text-red-500 text-xs mt-1">
                      {errors.passengers[index].lName.message}
                    </p>
                  )}
                </div>
  
                {/* DOB */}
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Date of Birth
                  </label>
                  <input
                    type="date"
                    {...register(`passengers.${index}.dob`)}
                    value={formPassengerData[index]?.dob || ""}
                    onChange={(e) =>
                      handleDobChange(e.target.value, index, type)
                    }
                    className="w-full px-3 py-2 border rounded-lg"
                  />
                </div>
  
                {/* Passport fields (if serType === 2) */}
                {formData.serType === 2 && (
                  <>
                    <div>
                      <label className="block text-sm font-medium mb-1">
                        Passport Number
                      </label>
                      <input
                        type="text"
                        {...register(`passengers.${index}.ppNo`)}
                        value={formPassengerData[index]?.ppNo || ""}
                        onChange={(e) =>
                          handlePassengerDataChange(
                            index,
                            "ppNo",
                            e.target.value
                          )
                        }
                        className="w-full px-3 py-2 border rounded-lg"
                      />
                    </div>
  
                    <div>
                      <label className="block text-sm font-medium mb-1">
                        Passport Issue Date
                      </label>
                      <input
                        type="date"
                        {...register(`passengers.${index}.ppIss`)}
                        value={formPassengerData[index]?.ppIss || ""}
                        onChange={(e) =>
                          handlePassengerDataChange(
                            index,
                            "ppIss",
                            e.target.value
                          )
                        }
                        className="w-full px-3 py-2 border rounded-lg"
                      />
                    </div>
  
                    <div>
                      <label className="block text-sm font-medium mb-1">
                        Passport Expiry Date
                      </label>
                      <input
                        type="date"
                        {...register(`passengers.${index}.ppExp`)}
                        value={formPassengerData[index]?.ppExp || ""}
                        onChange={(e) =>
                          handlePassengerDataChange(
                            index,
                            "ppExp",
                            e.target.value
                          )
                        }
                        className="w-full px-3 py-2 border rounded-lg"
                      />
                    </div>
  
                    <div>
                      <label className="block text-sm font-medium mb-1">
                        Nationality
                      </label>
                      <select
                        {...register(`passengers.${index}.ppNat`)}
                        value={formPassengerData[index]?.ppNat || "IN"}
                        onChange={(e) =>
                          handlePassengerDataChange(
                            index,
                            "ppNat",
                            e.target.value
                          )
                        }
                        className="w-full px-3 py-2 border rounded-lg"
                      >
                        <option value="IN">India</option>
                        <option value="US">United States</option>
                        <option value="UK">United Kingdom</option>
                        <option value="CA">Canada</option>
                      </select>
                    </div>
                  </>
                )}
              </div>
            </div>
          );
        })}
      </>
    );
  };
  
  export default PassengerDetails;