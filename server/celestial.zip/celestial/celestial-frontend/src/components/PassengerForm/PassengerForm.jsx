import { motion } from "framer-motion";
import { FaTimes, FaSpinner } from "react-icons/fa";
import PassengerDetails from "./PassengerDetails";
import ContactInfo from "./ContactInfo";
import SeatSelection from "./SeatSelection";
import SSROptions from "./SSROptions";

const PassengerForm = ({
  showPassengerForm,
  setShowPassengerForm,
  selectedFare,
  formData,
  formPassengerData,
  setFormPassengerData,
  contactInfo,
  setContactInfo,
  showSeatSelection,
  setShowSeatSelection,
  availableSeats,
  setAvailableSeats,
  selectedSeats,
  setSelectedSeats,
  isLoadingSeats,
  selectedSsr,
  setSelectedSsr,
  isBooking,
  handleSubmit,
  register,
  errors,
  handlePassengerDataChange,
  handleDobChange,
  fetchSeats,
  selectedFlightForPrice,
  statusRefdId,
  setIsOpen,
  handleBookFlight,
}) => {
  if (!showPassengerForm || !selectedFare) return null;

  return (
    <div className="fixed inset-0 bg-black/60 bg-opacity-50 flex items-center justify-center z-50 p-4">
      <motion.div
        className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
      >
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">
            Passenger Details
          </h2>
          <button
            onClick={() => setShowPassengerForm(false)}
            className="text-gray-500 hover:text-gray-700 text-2xl"
          >
            <FaTimes />
          </button>
        </div>

        <form
          onSubmit={handleSubmit(() => setIsOpen(true))}
          className="p-6"
        >
          <div className="space-y-6">
            <PassengerDetails
              formData={formData}
              formPassengerData={formPassengerData}
              handlePassengerDataChange={handlePassengerDataChange}
              handleDobChange={handleDobChange}
              register={register}
              errors={errors}
            />

            <SeatSelection
              showSeatSelection={showSeatSelection}
              availableSeats={availableSeats}
              selectedSeats={selectedSeats}
              setSelectedSeats={setSelectedSeats}
              isLoadingSeats={isLoadingSeats}
              fetchSeats={fetchSeats}
              selectedFlightForPrice={selectedFlightForPrice}
              statusRefdId={statusRefdId}
              formData={formData}
            />

            <ContactInfo
              contactInfo={contactInfo}
              setContactInfo={setContactInfo}
              register={register}
              errors={errors}
              setValue={() => {}}
            />

            <SSROptions
              selectedSsr={selectedSsr}
              setSelectedSsr={setSelectedSsr}
              setShowSeatSelection={setShowSeatSelection}
            />

            <ActionButtons
              setShowPassengerForm={setShowPassengerForm}
              isBooking={isBooking}
            />
          </div>
        </form>
      </motion.div>
    </div>
  );
};

const ActionButtons = ({ setShowPassengerForm, isBooking }) => (
  <div className="flex justify-end gap-3">
    <button
      type="button"
      onClick={() => setShowPassengerForm(false)}
      className="px-6 py-2 border rounded-lg hover:bg-gray-50"
    >
      Cancel
    </button>
    <button
      type="submit"
      className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
    >
      {isBooking ? "Booking..." : "Book Flight"}
    </button>
  </div>
);

export default PassengerForm;