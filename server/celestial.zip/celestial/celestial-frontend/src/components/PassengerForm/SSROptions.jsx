const SSROptions = ({ selectedSsr, setSelectedSsr, setShowSeatSelection }) => {
    return (
      <div className="border border-gray-200 rounded-lg p-4">
        <h3 className="font-semibold text-gray-900 mb-4">
          Special Services (SSR)
        </h3>
        <div className="space-y-4">
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => {
                setSelectedSsr({ type: "with" });
                setShowSeatSelection(true);
              }}
              className={`px-4 py-2 rounded-lg border transition-colors ${
                selectedSsr.type === "with"
                  ? "border-blue-600 bg-blue-50 text-blue-600"
                  : "border-gray-300 hover:bg-gray-50"
              }`}
            >
              Book with SSR
            </button>
            <button
              type="button"
              onClick={() => {
                setSelectedSsr({ type: "without" });
                setShowSeatSelection(false);
              }}
              className={`px-4 py-2 rounded-lg border transition-colors ${
                selectedSsr.type === "without"
                  ? "border-blue-600 bg-blue-50 text-blue-600"
                  : "border-gray-300 hover:bg-gray-50"
              }`}
            >
              Book without SSR
            </button>
          </div>
        </div>
      </div>
    );
  };
  
  export default SSROptions;