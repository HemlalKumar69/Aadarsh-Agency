import { FaSpinner } from "react-icons/fa";

const SeatSelection = ({
  showSeatSelection,
  availableSeats,
  selectedSeats,
  setSelectedSeats,
  isLoadingSeats,
  fetchSeats,
  selectedFlightForPrice,
  statusRefdId,
  formData,
}) => {
  if (!showSeatSelection) return null;

  return (
    <div className="border border-gray-200 rounded-lg p-4">
      <div className="mb-4">
        <button
          onClick={async () => {
            try {
              const flightId = selectedFlightForPrice.flightID || 75318;
              const refId = statusRefdId || "";
              await fetchSeats(flightId, refId);
            } catch (error) {
              console.error("Error fetching seats:", error);
            }
          }}
          disabled={isLoadingSeats}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoadingSeats
            ? "Loading Seats..."
            : "Load Available Seats"}
        </button>
      </div>

      {availableSeats.length > 0 && (
        <SeatMap
          availableSeats={availableSeats}
          selectedSeats={selectedSeats}
          setSelectedSeats={setSelectedSeats}
          formData={formData}
        />
      )}

      {availableSeats.length === 0 && !isLoadingSeats && (
        <div className="text-center py-4 text-gray-500">
          <p>
            No seats available. Click "Load Available Seats" to
            fetch seat information.
          </p>
        </div>
      )}
    </div>
  );
};

const SeatMap = ({ availableSeats, selectedSeats, setSelectedSeats, formData }) => {
  const maxRow = Math.max(...availableSeats.map((seat) => seat.row));
  const maxCol = Math.max(...availableSeats.map((seat) => seat.col));

  return (
    <div className="space-y-3">
      <h4 className="text-sm font-medium text-gray-700">
        Available Seats:
      </h4>

      <div className="bg-gray-50 p-4 rounded-lg">
        <div className="text-center mb-4">
          <div className="text-xs text-gray-500 mb-2">
            Aircraft Layout
          </div>
          <div className="flex justify-center items-center gap-2 text-xs">
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 bg-green-100 border border-green-300 rounded"></div>
              <span>Available</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 bg-red-100 border border-red-300 rounded"></div>
              <span>Booked</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 bg-blue-100 border border-blue-300 rounded"></div>
              <span>Selected</span>
            </div>
          </div>
        </div>

        {Array.from({ length: maxRow }, (_, row) => {
          const rowSeats = availableSeats.filter((seat) => seat.row === row + 1);
          return (
            <div
              key={row}
              className="flex justify-center gap-1 mb-1"
            >
              <div className="w-6 text-xs text-gray-500 flex items-center justify-center">
                {row + 1}
              </div>
              {Array.from({ length: maxCol }, (_, col) => {
                const seat = rowSeats.find((s) => s.col === col + 1);
                if (!seat) {
                  return <div key={col} className="w-8 h-8"></div>;
                }

                const isSelected = Object.values(selectedSeats).some(
                  (selectedSeat) => selectedSeat.seatID === seat.seatID
                );

                return (
                  <SeatButton
                    key={col}
                    seat={seat}
                    isSelected={isSelected}
                    setSelectedSeats={setSelectedSeats}
                    formData={formData}
                  />
                );
              })}
            </div>
          );
        })}
      </div>

      {Object.keys(selectedSeats).length > 0 && (
        <SelectedSeatsSummary selectedSeats={selectedSeats} />
      )}
    </div>
  );
};

const SeatButton = ({ seat, isSelected, setSelectedSeats, formData }) => {
  const handleSeatClick = () => {
    if (seat.isBooked) return;

    setSelectedSeats((prev) => {
      const newSeats = { ...prev };
      const maxSeats = (formData?.adults || 0) + (formData?.children || 0) + (formData?.infants || 0);

      if (isSelected) {
        Object.keys(newSeats).forEach((key) => {
          if (newSeats[key].seatID === seat.seatID) {
            delete newSeats[key];
          }
        });
        return newSeats;
      }

      const currentCount = Object.keys(newSeats).length;

      if (maxSeats <= 1) {
        return { [seat.seatID]: seat };
      }

      if (currentCount >= maxSeats) {
        const oldestKey = Object.keys(newSeats)[0];
        delete newSeats[oldestKey];
      }

      newSeats[seat.seatID] = seat;
      return newSeats;
    });
  };

  return (
    <button
      type="button"
      onClick={handleSeatClick}
      disabled={seat.isBooked}
      className={`w-8 h-8 text-xs border rounded transition-colors ${
        seat.isBooked
          ? "bg-red-100 border-red-300 text-red-500 cursor-not-allowed"
          : isSelected
          ? "bg-blue-600 text-white border-blue-600"
          : "bg-green-100 border-green-300 text-green-700 hover:bg-green-200"
      }`}
      title={`${seat.seatName} - ${seat.isBooked ? "Booked" : `₹${seat.seatAmt}`}`}
    >
      {seat.seatName}
    </button>
  );
};

const SelectedSeatsSummary = ({ selectedSeats }) => (
  <div className="mt-4 p-3 bg-blue-50 rounded-lg">
    <h5 className="text-sm font-medium text-blue-900 mb-2">
      Selected Seats:
    </h5>
    <div className="flex flex-wrap gap-2">
      {Object.entries(selectedSeats).map(([seatId, seat]) => (
        <span
          key={seatId}
          className="px-2 py-1 bg-blue-600 text-white text-xs rounded"
        >
          {seat.seatName} (₹{seat.seatAmt})
        </span>
      ))}
    </div>
    <div className="mt-2 text-sm text-blue-700">
      Total Seat Cost: ₹
      {Object.values(selectedSeats).reduce(
        (total, seat) => total + parseInt(seat.seatAmt || 0),
        0
      )}
    </div>
  </div>
);

export default SeatSelection;