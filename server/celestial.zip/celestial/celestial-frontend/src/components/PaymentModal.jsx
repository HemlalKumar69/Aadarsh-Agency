import React, { useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { FaTimes } from "react-icons/fa";

const PaymentModal = ({
  isOpen,
  onClose,
  onConfirm,
  fareData,
  isPaying,
  serType,
  seatTotal,
  ssrType,
  setAmount,
}) => {
  if (!isOpen) return null;

  // console.log(fareData);

  const {
    base = fareData?.Fare?.total?.base,
    inc = fareData?.Fare?.total?.inc,
    netfare = fareData?.Fare?.total?.netfare,
    tax = fareData?.Fare?.total?.tax,
    tds = fareData?.Fare?.total?.tds,
    total = fareData?.Fare?.total?.total,
  } = fareData || {};

  const numericInc = Number(inc || 0);
  const numericNet = Number(netfare || 0);
  const markupRate = serType === 1 ? 0.01 : 0.005; // 1% domestic, 0.5% international
  const computedAgentMarkup = Math.round(
    (numericInc + numericNet) * markupRate
  );
  const numericTotal = Number(total || 0);
  const numericSeatTotal = Number(seatTotal || 0);
  const effectiveSeatTotal = ssrType === "with" ? numericSeatTotal : 0;

  // Update parent amount from effect to avoid state updates during render
  useEffect(() => {
    if (typeof setAmount === "function") {
      setAmount(numericTotal + computedAgentMarkup + effectiveSeatTotal);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [numericTotal, computedAgentMarkup, effectiveSeatTotal]);

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <motion.div
          className="bg-white rounded-2xl shadow-lg w-full max-w-md md:max-w-lg p-6 relative"
          initial={{ y: 80, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 80, opacity: 0 }}
        >
          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-3 right-3 text-gray-600 hover:text-gray-800"
          >
            <FaTimes size={18} />
          </button>

          {/* Header */}
          <h2 className="text-xl md:text-2xl font-semibold text-center mb-4">
            Payment Summary
          </h2>

          {/* Fare Details */}
          <div className="space-y-3 text-gray-700">
            <div className="flex justify-between">
              <span>Convenience Fee:</span>
              <span>₹{computedAgentMarkup}</span>
            </div>
            <div className="flex justify-between">
              <span>Base Fare:</span>
              <span>₹{base}</span>
            </div>
            <div className="flex justify-between">
              <span>Inclusive Charges:</span>
              <span>₹{inc}</span>
            </div>
            <div className="flex justify-between">
              <span>Net Fare:</span>
              <span>₹{netfare}</span>
            </div>
            {effectiveSeatTotal > 0 && (
              <div className="flex justify-between">
                <span>Seat Cost:</span>
                <span>₹{effectiveSeatTotal}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span>Tax:</span>
              <span>₹{tax}</span>
            </div>
            <div className="flex justify-between">
              <span>TDS:</span>
              <span>₹{tds}</span>
            </div>
            <hr className="my-2" />
            <div className="flex justify-between font-semibold text-lg">
              <span>Total:</span>
              <span className="text-green-600">
                ₹{numericTotal + computedAgentMarkup + effectiveSeatTotal}
              </span>
            </div>
          </div>

          {/* Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 mt-6">
            <button
              onClick={onClose}
              className="w-full sm:w-1/2 py-2.5 bg-gray-200 rounded-xl hover:bg-gray-300 text-gray-800"
            >
              Cancel
            </button>
            <button
              onClick={onConfirm}
              disabled={isPaying}
              className={`w-full sm:w-1/2 py-2.5 rounded-xl text-white ${
                isPaying
                  ? "bg-blue-400 cursor-not-allowed"
                  : "bg-blue-600 hover:bg-blue-700"
              }`}
            >
              {isPaying ? "Processing..." : "Pay Now"}
            </button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default PaymentModal;
