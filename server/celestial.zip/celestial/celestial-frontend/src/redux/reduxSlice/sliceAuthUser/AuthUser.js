import { createSlice } from "@reduxjs/toolkit";
import {
  authUserLogin,
  authUserRegister,
  checkUserLogin,
  checkUserLogout,
} from "../../reduxThunk/thunkAuthUser/AuthUser";

const initialState = {
  authdata: [],
  loading: false,
  error: null,
  success: false,
};

const authUserSlice = createSlice({
  name: "authuser",
  initialState,
  extraReducers: (builder) => {
    builder
      .addCase(authUserLogin.pending, (state) => {
        state.loading = true;
        state.error = null;
        state.success = false;
      })
      .addCase(authUserLogin.fulfilled, (state, action) => {
        state.loading = false;
        state.authdata = action.payload;
        state.success = true;
      })
      .addCase(authUserLogin.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || "failed to login user";
        state.success = false;
      })
      .addCase(authUserRegister.pending, (state) => {
        state.loading = true;
        state.error = null;
        state.success = false;
      })
      .addCase(authUserRegister.fulfilled, (state, action) => {
        state.loading = false;
        state.authdata = action.payload;
        state.success = true;
      })
      .addCase(authUserRegister.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || "failed to login user";
        state.success = false;
      })
      .addCase(checkUserLogin.pending, (state) => {
        state.loading = true;
        state.error = null;
        state.success = false;
      })
      .addCase(checkUserLogin.fulfilled, (state, action) => {
        state.loading = false;
        state.authdata = action.payload;
        state.success = true;
      })
      .addCase(checkUserLogin.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || "failed to login user";
        state.success = false;
      })
      .addCase(checkUserLogout.pending, (state) => {
        state.loading = true;
        state.error = null;
        state.success = false;
      })
      .addCase(checkUserLogout.fulfilled, (state, action) => {
        state.loading = false;
        state.authdata = action.payload;
        state.success = true;
      })
      .addCase(checkUserLogout.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || "failed to logout user";
        state.success = false;
      });
  },
});

export default authUserSlice.reducer;
