import { createSlice } from "@reduxjs/toolkit";
import { fetchUserBookedTicked } from "../../reduxThunk/thunkBooking/Booking";

const initialState = {
  bookingdata: [],
  loading: false,
  error: null,
  success: false,
};

const bookingSlice = createSlice({
  name: "booking",
  initialState,
  extraReducers: (builder) => {
    builder
      .addCase(fetchUserBookedTicked.pending, (state) => {
        state.loading = true;
        state.error = null;
        state.success = false;
      })
      .addCase(fetchUserBookedTicked.fulfilled, (state, action) => {
        state.loading = false;
        state.bookingdata = action.payload;
        state.success = true;
      })
      .addCase(fetchUserBookedTicked.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || "failed to login user";
        state.success = false;
      });
  },
});

export default bookingSlice.reducer;
