import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

// const BASE_URL = "http://localhost:3000";
const BASE_URL = import.meta.env.VITE_URL || import.meta.env.VITE_URL2;

const getErrorMessage = (error) => {
  if (axios.isAxiosError(error)) {
    return error.response?.data?.error || error.message;
  }
  return error.message;
};

export const checkUserLogin = createAsyncThunk(
  "user/checkUserLogin",
  async (payload, { rejectWithValue }) => {
    try {
      // console.log(payload);
      const res = await axios.get(`${BASE_URL}/api/checkAuth`, {
        withCredentials: true,
      });
      // console.log(res);
      return res?.data;
    } catch (error) {
      // console.log(error);
      return rejectWithValue(getErrorMessage(error));
    }
  }
);

export const authUserLogin = createAsyncThunk(
  "user/login",
  async (payload, { rejectWithValue }) => {
    try {
      // console.log(payload);
      const res = await axios.post(`${BASE_URL}/api/auth/login`, payload, {
        withCredentials: true,
      });
      // console.log(res);
      return res?.data;
    } catch (error) {
      // console.log(error);
      return rejectWithValue(getErrorMessage(error));
    }
  }
);

export const authUserRegister = createAsyncThunk(
  "user/register",
  async (payload, { rejectWithValue }) => {
    try {
      // console.log(payload);
      const res = await axios.post(`${BASE_URL}/api/auth/register`, payload);
      // console.log(res);
      return res?.data;
    } catch (error) {
      // console.log(error);
      return rejectWithValue(getErrorMessage(error));
    }
  }
);

export const checkUserLogout = createAsyncThunk(
  "user/checkUserLogout",
  async (payload, { rejectWithValue }) => {
    try {
      // console.log(payload);
      const res = await axios.get(`${BASE_URL}/api/auth/logout`, {
        withCredentials: true,
      });
      // console.log(res);
      return res?.data;
    } catch (error) {
      // console.log(error);
      return rejectWithValue(getErrorMessage(error));
    }
  }
);
