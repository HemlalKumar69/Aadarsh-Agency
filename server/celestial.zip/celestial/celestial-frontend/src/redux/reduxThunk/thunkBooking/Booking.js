import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
// const BASE_URL = "http://localhost:3000";
const BASE_URL =  import.meta.env.VITE_URL || import.meta.env.VITE_URL2 ;

const getErrorMessage = (error) => {
  if (axios.isAxiosError(error)) {
    return error.response?.data?.error || error.message;
  }
  return error.message;
};

export const fetchUserBookedTicked = createAsyncThunk(
  "booked/fetchBookedTicked",
  async (_, { rejectWithValue }) => {
    try {
      const res = await axios.get(`${BASE_URL}/api/booking/`, {
        withCredentials: true,
      });
      return res?.data;
    } catch (error) {
      // console.log(error);
      return rejectWithValue(getErrorMessage(error));
    }
  }
);
