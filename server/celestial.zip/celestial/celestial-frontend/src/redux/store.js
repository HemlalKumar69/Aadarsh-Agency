import { configureStore } from "@reduxjs/toolkit";

import authUserReducer from "./reduxSlice/sliceAuthUser/AuthUser";
import bookingReducer from "./reduxSlice/sliceBooking/Booking.js";

export const store = configureStore({
  reducer: {
    auth: authUserReducer,
    booking: bookingReducer,
  },
});
