export const formatApiDateTime = (str) => {
    if (!str || str.length < 12) return "N/A";
    const y = Number(str.slice(0, 4));
    const m = Number(str.slice(4, 6)) - 1;
    const d = Number(str.slice(6, 8));
    const hh = Number(str.slice(8, 10));
    const mm = Number(str.slice(10, 12));
    const dt = new Date(y, m, d, hh, mm);
    return dt.toLocaleString(undefined, {
      year: "numeric",
      month: "short",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  };
  
  export const minutesToHm = (minsStr) => {
    const mins = Number(minsStr || 0);
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return `${h}h ${m}m`;
  };
  
  export const getSegments = (leg) => {
    if (!leg) return [];
    const vals = Array.isArray(leg) ? leg : Object.values(leg);
    return vals.filter((s) => s && s.flightNo);
  };
  
  export const getStopsText = (leg) => {
    const segs = getSegments(leg);
    const stops = Math.max(0, segs.length - 1);
    if (stops === 0) return "Non-stop";
    const vias = segs
      .slice(0, -1)
      .map((s) => s.arrCode)
      .join(", ");
    return `${stops} Stop${stops > 1 ? "s" : ""}${vias ? ` via ${vias}` : ""}`;
  };
  
  export const getTotalDurationMinutes = (leg) => {
    if (!leg) return 0;
    if (leg.durTotal) return Number(leg.durTotal);
    const segs = getSegments(leg);
    return segs.reduce((sum, s) => sum + Number(s.duration || 0), 0);
  };